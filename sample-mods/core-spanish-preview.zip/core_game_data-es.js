window.QR_CITY_QUEST_DATA = {
  "formatVersion": 1,
  "generatedFrom": "Gergo-app-prototype-item-actions-fixed + QR_City_Quest_Item_Data.md",
  "encounters": {
    "10": {
      "defaultPicture": "warrior",
      "requiredArea": "CASTLE_SIDE",
      "startPage": "1001",
      "pages": {
        "1001": {
          "id": "1001",
          "speaker": "Warrior",
          "text": "Hello! If you wanna get inside, you have to know the password!",
          "buttons": [
            {
              "index": 1,
              "label": "Okay, bye",
              "next": "1001"
            },
            {
              "index": 2,
              "label": "I don't know, but I show you something",
              "next": "1002"
            },
            {
              "index": 3,
              "label": "I know",
              "next": "1003"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            },
            {
              "type": "ADD_KNOWLEDGE",
              "data": "castle_requires_password"
            }
          ],
          "condition": {}
        },
        "1002": {
          "id": "1002",
          "picture": "warrior-arms-crossed",
          "speaker": "Warrior",
          "text": "Choose an item from your inventory.",
          "buttons": [
            {
              "index": 1,
              "label": "Choose Item",
              "next": "1005"
            }
          ],
          "actions": [
            {
              "type": "DROPDOWN_INVENTORY",
              "options": [
                {
                  "value": "Ruby Sword",
                  "label": "Ruby Sword",
                  "next": "1005"
                },
                {
                  "value": "Magic Branch",
                  "label": "Magic Branch",
                  "next": "1010"
                }
              ],
              "otherNext": "1004"
            }
          ],
          "condition": {}
        },
        "1003": {
          "id": "1003",
          "speaker": "Warrior",
          "text": "Then what is it?",
          "buttons": [
            {
              "index": 1,
              "label": "Choose First Part",
              "next": "1006"
            }
          ],
          "actions": [
            {
              "type": "DROPDOWN_CHOICE",
              "options": [
                {
                  "label": "Apple",
                  "next": "1006"
                },
                {
                  "label": "Orange",
                  "next": "1008"
                },
                {
                  "label": "Plum",
                  "next": "1008"
                },
                {
                  "label": "Pear",
                  "next": "1008"
                },
                {
                  "label": "Peach",
                  "next": "1008"
                }
              ]
            }
          ],
          "condition": {}
        },
        "1004": {
          "id": "1004",
          "picture": "warrior-holds-sword",
          "speaker": "Warrior",
          "text": "No you can't get inside with that.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "1001"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            }
          ],
          "condition": {}
        },
        "1005": {
          "id": "1005",
          "speaker": "Warrior",
          "text": "Ha you wanna fight?",
          "buttons": [
            {
              "index": 1,
              "label": "No bye",
              "next": "1001"
            },
            {
              "index": 2,
              "label": "I wanna give it to you",
              "next": "1004"
            },
            {
              "index": 3,
              "label": "Yes",
              "next": "1009"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            }
          ],
          "condition": {}
        },
        "1006": {
          "id": "1006",
          "speaker": "Warrior",
          "text": "Choose the second part.",
          "buttons": [
            {
              "index": 1,
              "label": "Choose Second Part",
              "next": "1007"
            }
          ],
          "actions": [
            {
              "type": "DROPDOWN_CHOICE",
              "options": [
                {
                  "label": "Pie",
                  "next": "1007"
                },
                {
                  "label": "Juice",
                  "next": "1008"
                },
                {
                  "label": "Tree",
                  "next": "1008"
                },
                {
                  "label": "Flavour",
                  "next": "1008"
                },
                {
                  "label": "Fruit",
                  "next": "1008"
                }
              ]
            }
          ],
          "condition": {}
        },
        "1007": {
          "id": "1007",
          "picture": "warrior-open-gate-side",
          "speaker": "Warrior",
          "text": "Well... that's correct! You may go in.",
          "buttons": [
            {
              "index": 1,
              "label": "YAY",
              "next": "1011"
            }
          ],
          "actions": [
            {
              "type": "OPEN_CASTLE"
            }
          ],
          "condition": {}
        },
        "1008": {
          "id": "1008",
          "picture": "warrior-holds-sword",
          "speaker": "Warrior",
          "text": "Well... that's incorrect. You must stay out!",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "1001"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            }
          ],
          "condition": {}
        },
        "1009": {
          "id": "1009",
          "picture": "warrior-defeated-weaponless",
          "speaker": "Warrior",
          "text": "Let's go!! Nothing happens. A dinosaur jumps out of your hand and two strikes it defeats the guard.",
          "buttons": [
            {
              "index": 1,
              "label": "May I go in?",
              "next": "1007"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "1010": {
          "id": "1010",
          "speaker": "Warrior",
          "text": "You swing it. Little rainbow sparkles, but nothing else.",
          "buttons": [
            {
              "index": 1,
              "label": "Bye",
              "next": "1001"
            },
            {
              "index": 2,
              "label": "Ha ha ha ha ha ha ha ha...",
              "next": "1010"
            },
            {
              "index": 3,
              "label": "I wanna give it to you",
              "next": "1004"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            }
          ],
          "condition": {}
        },
        "1011": {
          "id": "1011",
          "speaker": "Warrior",
          "text": "You won!",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "TITLE_SCREEN"
            }
          ],
          "actions": [],
          "condition": {}
        }
      }
    },
    "33": {
      "startPage": "3301",
      "pages": {
        "3301": {
          "id": "3301",
          "speaker": "Bird",
          "text": "Hi! Could you bring me some things?",
          "buttons": [
            {
              "index": 1,
              "label": "Yes",
              "next": "3302"
            },
            {
              "index": 2,
              "label": "No",
              "next": "3303"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "3302": {
          "id": "3302",
          "speaker": "Bird",
          "text": "First, I need some straw for building my nest.",
          "buttons": [
            {
              "index": 1,
              "label": "Okay",
              "next": "3304"
            },
            {
              "index": 2,
              "label": "I have some straw",
              "next": "3305"
            }
          ],
          "actions": [
            {
              "type": "START_QUEST",
              "data": "Bird1"
            },
            {
              "type": "NEXT_SCAN",
              "buttonIndex": 1
            }
          ],
          "condition": {}
        },
        "3303": {
          "id": "3303",
          "speaker": "Bird",
          "text": "Then please let me work.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "3301"
            },
            {
              "index": 2,
              "label": "Sure",
              "next": "3304"
            },
            {
              "index": 3,
              "label": "Alright",
              "next": "3307"
            },
            {
              "index": 4,
              "label": "Okay",
              "next": "3309"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN",
              "buttonIndex": 1
            },
            {
              "type": "NEXT_SCAN",
              "buttonIndex": 2
            },
            {
              "type": "NEXT_SCAN",
              "buttonIndex": 3
            },
            {
              "type": "NEXT_SCAN",
              "buttonIndex": 4
            }
          ],
          "condition": {
            "1": "save.quests[\"Bird1\"] !== \"active\" && save.quests[\"Bird2\"] !== \"active\" && save.quests[\"Bird3\"] !== \"active\"",
            "2": "save.quests[\"Bird1\"] === \"active\"",
            "3": "save.quests[\"Bird2\"] === \"active\"",
            "4": "save.quests[\"Bird3\"] === \"active\""
          }
        },
        "3304": {
          "id": "3304",
          "speaker": "Bird",
          "text": "Hello!!! Did you bring straw?",
          "buttons": [
            {
              "index": 1,
              "label": "Yes",
              "next": "3305"
            },
            {
              "index": 2,
              "label": "No",
              "next": "3303"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "3305": {
          "id": "3305",
          "speaker": "Bird",
          "text": "Well, show me!",
          "buttons": [
            {
              "index": 1,
              "label": "Items",
              "next": "3306"
            }
          ],
          "actions": [
            {
              "type": "DROPDOWN_INVENTORY",
              "options": [
                {
                  "value": "Straw",
                  "label": "Straw",
                  "next": "3306"
                },
                {
                  "value": "Mosquito",
                  "label": "Mosquito",
                  "next": "3308"
                },
                {
                  "value": "Sketch3",
                  "label": "Sketch 3",
                  "next": "3310"
                }
              ],
              "otherNext": "3303"
            }
          ],
          "condition": {}
        },
        "3306": {
          "id": "3306",
          "speaker": "Bird",
          "text": "Next, please get me a mosquito from the mosquito hunters.",
          "buttons": [
            {
              "index": 1,
              "label": "Okay",
              "next": "3307"
            }
          ],
          "actions": [
            {
              "type": "REMOVE_ITEM",
              "data": "Straw"
            },
            {
              "type": "COMPLETE_QUEST",
              "data": "Bird1"
            },
            {
              "type": "START_QUEST",
              "data": "Bird2"
            },
            {
              "type": "NEXT_SCAN"
            }
          ],
          "condition": {}
        },
        "3307": {
          "id": "3307",
          "speaker": "Bird",
          "text": "Did you bring a mosquito?",
          "buttons": [
            {
              "index": 1,
              "label": "Yes",
              "next": "3305"
            },
            {
              "index": 2,
              "label": "No",
              "next": "3303"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "3308": {
          "id": "3308",
          "speaker": "Bird",
          "text": "Finally, could you find me a sketch of a suitable place where I could build my nest?",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "3309"
            }
          ],
          "actions": [
            {
              "type": "REMOVE_ITEM",
              "data": "Mosquito"
            },
            {
              "type": "COMPLETE_QUEST",
              "data": "Bird2"
            },
            {
              "type": "START_QUEST",
              "data": "Bird3"
            },
            {
              "type": "NEXT_SCAN"
            }
          ],
          "condition": {}
        },
        "3309": {
          "id": "3309",
          "speaker": "Bird",
          "text": "Hello! Did you bring the sketch of a suitable nesting place?",
          "buttons": [
            {
              "index": 1,
              "label": "Yes",
              "next": "3305"
            },
            {
              "index": 2,
              "label": "No",
              "next": "3303"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "3310": {
          "id": "3310",
          "speaker": "Bird",
          "text": "Thank you! Now I can finally build my nest! In return, I can tell you that the 3rd part of the password is \"011\". Now I have to hurry and build my nest.",
          "buttons": [
            {
              "index": 1,
              "label": "Bye!",
              "next": "3311"
            }
          ],
          "actions": [
            {
              "type": "REMOVE_ITEM",
              "data": "Sketch3"
            },
            {
              "type": "COMPLETE_QUEST",
              "data": "Bird3"
            },
            {
              "type": "ADD_KNOWLEDGE",
              "data": "Password3"
            },
            {
              "type": "NEXT_SCAN"
            }
          ],
          "condition": {}
        },
        "3311": {
          "id": "3311",
          "speaker": "Bird",
          "text": "The little bird isn't here.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "3311"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            }
          ],
          "condition": {},
          "picture": "bird-gone"
        }
      },
      "defaultPicture": "bird"
    },
    "34": {
      "startPage": "3401",
      "pages": {
        "3401": {
          "id": "3401",
          "speaker": "Otter",
          "text": "Hi! How's your day? Are you looking for something?",
          "buttons": [
            {
              "index": 1,
              "label": "I'm having a good day!",
              "next": "3402"
            },
            {
              "index": 2,
              "label": "Maybe...",
              "next": "3403"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "3402": {
          "id": "3402",
          "speaker": "Otter",
          "text": "Really? That's fantastic! That reminds me... I don't even know...",
          "buttons": [
            {
              "index": 1,
              "label": "What is it?",
              "next": "3404"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "3403": {
          "id": "3403",
          "speaker": "Otter",
          "text": "Wow! That sounds exciting! I wanted to look for something too...",
          "buttons": [
            {
              "index": 1,
              "label": "What?",
              "next": "3404"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "3404": {
          "id": "3404",
          "speaker": "Otter",
          "text": "Yeah! I should catch a big fish because I'm already hungry! Well, bye! I'll be back.",
          "buttons": [
            {
              "index": 1,
              "label": "Bye",
              "next": "3406"
            }
          ],
          "actions": [
            {
              "type": "START_TIMER",
              "durationMs": 300000,
              "waitPage": "3405"
            }
          ],
          "condition": {}
        },
        "3405": {
          "id": "3405",
          "speaker": "Otter",
          "text": "The otter isn't here right now...",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "HOME"
            }
          ],
          "actions": [],
          "condition": {},
          "picture": "otter-gone"
        },
        "3406": {
          "id": "3406",
          "speaker": "Otter",
          "text": "Hi! My belly is full now!",
          "buttons": [
            {
              "index": 1,
              "label": "How are you?",
              "next": "3407"
            },
            {
              "index": 2,
              "label": "What fish did you catch?",
              "next": "3408"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "3407": {
          "id": "3407",
          "speaker": "Otter",
          "text": "Good. A tasty lunch always cheers me up! But now I have to go meet someone...",
          "buttons": [
            {
              "index": 1,
              "label": "Bye!",
              "next": "3409"
            }
          ],
          "actions": [
            {
              "type": "START_TIMER",
              "durationMs": 300000,
              "waitPage": "3405"
            }
          ],
          "condition": {}
        },
        "3408": {
          "id": "3408",
          "speaker": "Otter",
          "text": "I caught a big carp. And a blobfish too. But that was yummy, my boy... Anyway, I'm off now. I've got something to gobble up!",
          "buttons": [
            {
              "index": 1,
              "label": "Bye",
              "next": "3409"
            }
          ],
          "actions": [
            {
              "type": "START_TIMER",
              "durationMs": 300000,
              "waitPage": "3405"
            }
          ],
          "condition": {}
        },
        "3409": {
          "id": "3409",
          "speaker": "Otter",
          "text": "Hi! It was so nice talking with you! Are we friends now?",
          "buttons": [
            {
              "index": 1,
              "label": "Yes",
              "next": "3410"
            },
            {
              "index": 2,
              "label": "No. Bye!",
              "next": "3409"
            },
            {
              "index": 3,
              "label": "Of course",
              "next": "3411"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN",
              "buttonIndex": 2
            }
          ],
          "condition": {
            "1": "!knowledge.includes(\"Password1\")",
            "2": "!knowledge.includes(\"Password1\")",
            "3": "knowledge.includes(\"Password1\")"
          }
        },
        "3410": {
          "id": "3410",
          "speaker": "Otter",
          "text": "Then I will tell you that the first part of the password is: \"7\".",
          "buttons": [
            {
              "index": 1,
              "label": "Thanks",
              "next": "3409"
            }
          ],
          "actions": [
            {
              "type": "ADD_KNOWLEDGE",
              "data": "Password1"
            },
            {
              "type": "NEXT_SCAN"
            }
          ],
          "condition": {}
        },
        "3411": {
          "id": "3411",
          "speaker": "Otter",
          "text": "Good to know we still feel the same way about each other.",
          "buttons": [
            {
              "index": 1,
              "label": "Yes",
              "next": "3409"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            }
          ],
          "condition": {}
        }
      },
      "defaultPicture": "otter"
    },
    "35": {
      "startPage": "3501",
      "pages": {
        "3501": {
          "id": "3501",
          "speaker": "Heron",
          "text": "What are you looking for here?",
          "buttons": [
            {
              "index": 1,
              "label": "Nothing",
              "next": "3502"
            },
            {
              "index": 2,
              "label": "Anything",
              "next": "3503"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "3502": {
          "id": "3502",
          "speaker": "Heron",
          "text": "Then get out of here!",
          "buttons": [
            {
              "index": 1,
              "label": "Okay...",
              "next": "3506"
            },
            {
              "index": 2,
              "label": "Fine...",
              "next": "3504"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN",
              "buttonIndex": 1
            },
            {
              "type": "NEXT_SCAN",
              "buttonIndex": 2
            }
          ],
          "condition": {
            "1": "save.quests[\"Gém1\"] === \"active\"",
            "2": "save.quests[\"Gém1\"] === undefined"
          }
        },
        "3503": {
          "id": "3503",
          "speaker": "Heron",
          "text": "Well, you can find quite a lot of \"anything\" around here! You did not need to bother me for that!",
          "buttons": [
            {
              "index": 1,
              "label": "Okay. Bye...",
              "next": "3504"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            }
          ],
          "condition": {}
        },
        "3504": {
          "id": "3504",
          "speaker": "Heron",
          "text": "Why are you bothering me again?",
          "buttons": [
            {
              "index": 1,
              "label": "I was just wandering",
              "next": "3505"
            },
            {
              "index": 2,
              "label": "Nothing",
              "next": "3502"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "3505": {
          "id": "3505",
          "speaker": "Heron",
          "text": "I won't tell you anything until you get me a golden apple from the tree!",
          "buttons": [
            {
              "index": 1,
              "label": "Okay",
              "next": "3506"
            }
          ],
          "actions": [
            {
              "type": "START_QUEST",
              "data": "Gém1"
            },
            {
              "type": "NEXT_SCAN"
            }
          ],
          "condition": {}
        },
        "3506": {
          "id": "3506",
          "speaker": "Heron",
          "text": "Did you get it?",
          "buttons": [
            {
              "index": 1,
              "label": "Items",
              "next": "3507"
            }
          ],
          "actions": [
            {
              "type": "DROPDOWN_INVENTORY",
              "options": [
                {
                  "value": "Golden Apple",
                  "label": "Golden Apple",
                  "next": "3507"
                }
              ],
              "otherNext": "3504"
            }
          ],
          "condition": {}
        },
        "3507": {
          "id": "3507",
          "speaker": "Heron",
          "text": "Thanks, thank you! In return I will tell you that the second part of the password is \"891\". Now get out of here!",
          "buttons": [
            {
              "index": 1,
              "label": "Okay",
              "next": "3508"
            }
          ],
          "actions": [
            {
              "type": "REMOVE_ITEM",
              "data": "Golden Apple"
            },
            {
              "type": "COMPLETE_QUEST",
              "data": "Gém1"
            },
            {
              "type": "ADD_KNOWLEDGE",
              "data": "Password2"
            },
            {
              "type": "NEXT_SCAN"
            }
          ],
          "condition": {}
        },
        "3508": {
          "id": "3508",
          "speaker": "Heron",
          "text": "Scram.",
          "buttons": [
            {
              "index": 1,
              "label": "Bye",
              "next": "3508"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            }
          ],
          "condition": {}
        }
      },
      "defaultPicture": "heron"
    },
    "45": {
      "startPage": "4501",
      "defaultPicture": "scribe",
      "overdueItemTimers": {
        "Worm Book": "4514",
        "Magic Book": "4514",
        "Crystal Book": "4514"
      },
      "pages": {
        "4501": {
          "id": "4501",
          "speaker": "Scribe Worm",
          "text": "Hi! Do you want to visit the library?",
          "buttons": [
            {
              "index": 1,
              "label": "Yes",
              "next": "4502"
            },
            {
              "index": 2,
              "label": "No",
              "next": "4503"
            },
            {
              "index": 3,
              "label": "I brought a book back",
              "next": "4508"
            }
          ],
          "actions": [],
          "condition": {
            "3": "save.inventory.includes(\"Worm Book\") || save.inventory.includes(\"Magic Book\") || save.inventory.includes(\"Crystal Book\")"
          }
        },
        "4502": {
          "id": "4502",
          "speaker": "Scribe Worm",
          "text": "Which book would you like to borrow?",
          "buttons": [
            {
              "index": 1,
              "label": "The History of the Worms",
              "next": "4504"
            },
            {
              "index": 2,
              "label": "The Magic Pebble",
              "next": "4505"
            },
            {
              "index": 3,
              "label": "Crystal Facts",
              "next": "4506"
            }
          ],
          "actions": [],
          "condition": {
            "1": "!save.inventory.includes(\"Worm Book\")",
            "2": "!save.inventory.includes(\"Magic Book\")",
            "3": "!save.inventory.includes(\"Crystal Book\")"
          },
          "picture": "scribe-books"
        },
        "4503": {
          "id": "4503",
          "speaker": "Scribe Worm",
          "text": "Do you want a magnifier? These books are very small.",
          "buttons": [
            {
              "index": 1,
              "label": "Yes",
              "next": "4507"
            },
            {
              "index": 2,
              "label": "No, bye!",
              "next": "4501"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN",
              "buttonIndex": 2
            }
          ],
          "condition": {}
        },
        "4504": {
          "id": "4504",
          "speaker": "Scribe Worm",
          "text": "Here you go: The History of the Worms. You have seven minutes with it.",
          "buttons": [
            {
              "index": 1,
              "label": "Okay",
              "next": "4503"
            }
          ],
          "actions": [
            {
              "type": "ADD_ITEM",
              "data": "Worm Book"
            },
            {
              "type": "START_ITEM_TIMER",
              "data": "Worm Book",
              "durationMs": 420000,
              "unlessHasItem": "Premium Library Card"
            }
          ],
          "condition": {},
          "picture": "scribe-gives-book"
        },
        "4505": {
          "id": "4505",
          "speaker": "Scribe Worm",
          "text": "Here you go: The Magic Pebble. You have seven minutes with it.",
          "buttons": [
            {
              "index": 1,
              "label": "Okay",
              "next": "4503"
            }
          ],
          "actions": [
            {
              "type": "ADD_ITEM",
              "data": "Magic Book"
            },
            {
              "type": "START_ITEM_TIMER",
              "data": "Magic Book",
              "durationMs": 420000,
              "unlessHasItem": "Premium Library Card"
            }
          ],
          "condition": {},
          "picture": "scribe-gives-book"
        },
        "4506": {
          "id": "4506",
          "speaker": "Scribe Worm",
          "text": "Here you go: Crystal Facts. You have seven minutes with it.",
          "buttons": [
            {
              "index": 1,
              "label": "Okay",
              "next": "4503"
            }
          ],
          "actions": [
            {
              "type": "ADD_ITEM",
              "data": "Crystal Book"
            },
            {
              "type": "START_ITEM_TIMER",
              "data": "Crystal Book",
              "durationMs": 420000,
              "unlessHasItem": "Premium Library Card"
            }
          ],
          "condition": {},
          "picture": "scribe-gives-book"
        },
        "4507": {
          "id": "4507",
          "speaker": "Scribe Worm",
          "text": "Here you go! If you lose it, just ask for another one. I have plenty.",
          "buttons": [
            {
              "index": 1,
              "label": "Thanks!",
              "next": "4501"
            }
          ],
          "actions": [
            {
              "type": "ADD_ITEM",
              "data": "Magnifying Glass"
            },
            {
              "type": "NEXT_SCAN"
            }
          ],
          "condition": {},
          "picture": "scribe-gives-magnifier-card"
        },
        "4508": {
          "id": "4508",
          "speaker": "Scribe Worm",
          "text": "You brought it back? Then give it here!",
          "buttons": [
            {
              "index": 1,
              "label": "Items",
              "next": "4509"
            }
          ],
          "actions": [
            {
              "type": "DROPDOWN_INVENTORY",
              "options": [
                {
                  "value": "Crystal Book",
                  "label": "Crystal Facts",
                  "next": "4509"
                },
                {
                  "value": "Magic Book",
                  "label": "The Magic Pebble",
                  "next": "4510"
                },
                {
                  "value": "Worm Book",
                  "label": "The History of the Worms",
                  "next": "4511"
                }
              ],
              "otherNext": "4512"
            }
          ],
          "condition": {}
        },
        "4509": {
          "id": "4509",
          "speaker": "Scribe Worm",
          "text": "Thanks, Crystal Facts is back.",
          "buttons": [
            {
              "index": 1,
              "label": "Okay",
              "next": "4513"
            },
            {
              "index": 2,
              "label": "Okay",
              "next": "4501"
            }
          ],
          "actions": [
            {
              "type": "REMOVE_ITEM",
              "data": "Crystal Book"
            },
            {
              "type": "STOP_ITEM_TIMER",
              "data": "Crystal Book"
            },
            {
              "type": "NEXT_SCAN",
              "buttonIndex": 2
            }
          ],
          "condition": {
            "1": "had_item.includes(\"Worm Book\") && had_item.includes(\"Magic Book\") && had_item.includes(\"Crystal Book\")",
            "2": "!(had_item.includes(\"Worm Book\") && had_item.includes(\"Magic Book\") && had_item.includes(\"Crystal Book\"))"
          }
        },
        "4510": {
          "id": "4510",
          "speaker": "Scribe Worm",
          "text": "Thanks, The Magic Pebble is back.",
          "buttons": [
            {
              "index": 1,
              "label": "Okay",
              "next": "4513"
            },
            {
              "index": 2,
              "label": "Okay",
              "next": "4501"
            }
          ],
          "actions": [
            {
              "type": "REMOVE_ITEM",
              "data": "Magic Book"
            },
            {
              "type": "STOP_ITEM_TIMER",
              "data": "Magic Book"
            },
            {
              "type": "NEXT_SCAN",
              "buttonIndex": 2
            }
          ],
          "condition": {
            "1": "had_item.includes(\"Worm Book\") && had_item.includes(\"Magic Book\") && had_item.includes(\"Crystal Book\")",
            "2": "!(had_item.includes(\"Worm Book\") && had_item.includes(\"Magic Book\") && had_item.includes(\"Crystal Book\"))"
          }
        },
        "4511": {
          "id": "4511",
          "speaker": "Scribe Worm",
          "text": "Thanks, The History of the Worms is back.",
          "buttons": [
            {
              "index": 1,
              "label": "Okay",
              "next": "4513"
            },
            {
              "index": 2,
              "label": "Okay",
              "next": "4501"
            }
          ],
          "actions": [
            {
              "type": "REMOVE_ITEM",
              "data": "Worm Book"
            },
            {
              "type": "STOP_ITEM_TIMER",
              "data": "Worm Book"
            },
            {
              "type": "NEXT_SCAN",
              "buttonIndex": 2
            }
          ],
          "condition": {
            "1": "had_item.includes(\"Worm Book\") && had_item.includes(\"Magic Book\") && had_item.includes(\"Crystal Book\")",
            "2": "!(had_item.includes(\"Worm Book\") && had_item.includes(\"Magic Book\") && had_item.includes(\"Crystal Book\"))"
          }
        },
        "4512": {
          "id": "4512",
          "speaker": "Scribe Worm",
          "text": "That doesn't belong to the library!",
          "buttons": [
            {
              "index": 1,
              "label": "Sorry!",
              "next": "4501"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            }
          ],
          "condition": {},
          "picture": "scribe-annoyed"
        },
        "4513": {
          "id": "4513",
          "speaker": "Scribe Worm",
          "text": "Wait! Our most determined readers receive a Premium Library Card. You borrowed all three books, so this is yours now. It gives you unlimited access to the library books!",
          "buttons": [
            {
              "index": 1,
              "label": "Thank you!",
              "next": "4501"
            }
          ],
          "actions": [
            {
              "type": "ADD_ITEM",
              "data": "Premium Library Card"
            },
            {
              "type": "NEXT_SCAN"
            }
          ],
          "condition": {},
          "picture": "scribe-premium-card"
        },
        "4514": {
          "id": "4514",
          "speaker": "Scribe Worm",
          "text": "Give me the book you borrowed because the time limit is over!",
          "buttons": [
            {
              "index": 1,
              "label": "Items",
              "next": "4509"
            }
          ],
          "actions": [
            {
              "type": "DROPDOWN_INVENTORY",
              "options": [
                {
                  "value": "Crystal Book",
                  "label": "Crystal Facts",
                  "next": "4509"
                },
                {
                  "value": "Magic Book",
                  "label": "The Magic Pebble",
                  "next": "4510"
                },
                {
                  "value": "Worm Book",
                  "label": "The History of the Worms",
                  "next": "4511"
                }
              ],
              "otherNext": "4515"
            }
          ],
          "condition": {}
        },
        "4515": {
          "id": "4515",
          "speaker": "Scribe Worm",
          "text": "Not that thing!!!!",
          "buttons": [
            {
              "index": 1,
              "label": "Okay!",
              "next": "4514"
            },
            {
              "index": 2,
              "label": "I'm not giving it back",
              "next": "4516"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN",
              "buttonIndex": 2
            }
          ],
          "condition": {}
        },
        "4516": {
          "id": "4516",
          "speaker": "Scribe Worm",
          "text": "Get out!!!",
          "buttons": [
            {
              "index": 1,
              "label": "Okay",
              "next": "4516"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            }
          ],
          "condition": {},
          "picture": "scribe-annoyed"
        }
      }
    },
    "01": {
      "defaultPicture": "child",
      "startPage": "0101",
      "pages": {
        "0101": {
          "id": "0101",
          "speaker": "Child",
          "text": "Will ya' buy me some sweets?",
          "buttons": [
            {
              "index": 1,
              "label": "Yes",
              "next": "0102"
            },
            {
              "index": 2,
              "label": "No",
              "next": "0103"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "0102": {
          "id": "0102",
          "speaker": "Child",
          "text": "You can buy them from the Merchant.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "0104"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            },
            {
              "type": "START_QUEST",
              "data": "Buy Sweets"
            },
            {
              "type": "ADD_KNOWLEDGE",
              "data": "sweets_from_merchant"
            }
          ],
          "condition": {}
        },
        "0103": {
          "id": "0103",
          "picture": "child-back",
          "speaker": "Child",
          "text": "Okay then, leave me alone!",
          "buttons": [
            {
              "index": 1,
              "label": "Bye",
              "next": "0101"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            }
          ],
          "condition": {}
        },
        "0104": {
          "id": "0104",
          "speaker": "Child",
          "text": "Do you have any sweets?",
          "buttons": [
            {
              "index": 1,
              "label": "Yes",
              "next": "0105"
            },
            {
              "index": 2,
              "label": "No",
              "next": "0108"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "0105": {
          "id": "0105",
          "speaker": "Child",
          "text": "Show me!",
          "buttons": [
            {
              "index": 1,
              "label": "Choose Item",
              "next": "0106"
            }
          ],
          "actions": [
            {
              "type": "DROPDOWN_INVENTORY",
              "options": [
                {
                  "value": "Sweets",
                  "label": "Sweets",
                  "next": "0106"
                }
              ],
              "otherNext": "0103"
            }
          ],
          "condition": {}
        },
        "0106": {
          "id": "0106",
          "speaker": "Child",
          "text": "I heard the Messenger telling a password to the Warrior. It was something like \"...Pie\".",
          "buttons": [
            {
              "index": 1,
              "label": "Thanks",
              "next": "0107"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            },
            {
              "type": "REMOVE_ITEM",
              "data": "Sweets"
            },
            {
              "type": "COMPLETE_QUEST",
              "data": "Buy Sweets"
            },
            {
              "type": "ADD_KNOWLEDGE",
              "data": "password_ending_pie"
            }
          ],
          "condition": {}
        },
        "0107": {
          "id": "0107",
          "picture": "child-gone",
          "speaker": "Child",
          "text": "The child can't be seen.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "0107"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            }
          ],
          "condition": {}
        },
        "0108": {
          "id": "0108",
          "picture": "child-back",
          "speaker": "Child",
          "text": "Next time, have them!",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "0104"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            }
          ],
          "condition": {}
        }
      }
    },
    "02": {
      "defaultPicture": "merchant",
      "startPage": "0201",
      "pages": {
        "0201": {
          "id": "0201",
          "speaker": "Mercader",
          "text": "¡Hola, cliente! ¿Quieres comprar algo? (Vista previa en español)",
          "buttons": [
            {
              "index": 1,
              "label": "Sí",
              "next": "0202"
            },
            {
              "index": 2,
              "label": "No",
              "next": "0203"
            },
            {
              "index": 3,
              "label": "Yes",
              "next": "0215"
            }
          ],
          "actions": [],
          "condition": {
            "1": "!had_item.includes(\"Sweets\") || !had_item.includes(\"Old Scroll\")",
            "3": "had_item.includes(\"Sweets\") && had_item.includes(\"Old Scroll\")"
          }
        },
        "0202": {
          "id": "0202",
          "picture": "merchant-choice-items",
          "speaker": "Merchant",
          "text": "I have a few things to sell. Which one do you prefer?",
          "buttons": [
            {
              "index": 1,
              "label": "Sweets",
              "next": "0204"
            },
            {
              "index": 2,
              "label": "Old Scroll",
              "next": "0205"
            },
            {
              "index": 3,
              "label": "I don't need any now.",
              "next": "0203"
            }
          ],
          "actions": [],
          "condition": {
            "1": "!had_item.includes(\"Sweets\")",
            "2": "!had_item.includes(\"Old Scroll\")",
            "3": "had_item.includes(\"Sweets\") || had_item.includes(\"Old Scroll\")"
          }
        },
        "0203": {
          "id": "0203",
          "speaker": "Merchant",
          "text": "Okay, but do you have some free time? I would be happy if you could get me some unique ingredients.",
          "buttons": [
            {
              "index": 1,
              "label": "No I gotta go",
              "next": "0201"
            },
            {
              "index": 2,
              "label": "Yeah",
              "next": "0206"
            },
            {
              "index": 3,
              "label": "Yeah",
              "next": "0214"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            }
          ],
          "condition": {
            "2": "save.quests[\"Get Blobfish for Merchant\"] === undefined",
            "3": "save.quests[\"Get Blobfish for Merchant\"] !== undefined"
          }
        },
        "0204": {
          "id": "0204",
          "picture": "merchant-asking-hand",
          "speaker": "Merchant",
          "text": "Okay it will be a gold coin. Choose one of your items from your inventory.",
          "buttons": [
            {
              "index": 1,
              "label": "Choose Item",
              "next": "0207"
            }
          ],
          "actions": [
            {
              "type": "DROPDOWN_INVENTORY",
              "options": [
                {
                  "value": "Gold Coin",
                  "label": "Gold Coin",
                  "next": "0207"
                }
              ],
              "otherNext": "0208"
            }
          ],
          "condition": {}
        },
        "0205": {
          "id": "0205",
          "picture": "merchant-asking-hand",
          "speaker": "Merchant",
          "text": "Okay it will be a Priclys Feather. Choose one of your items from your inventory.",
          "buttons": [
            {
              "index": 1,
              "label": "Choose Item",
              "next": "0209"
            }
          ],
          "actions": [
            {
              "type": "DROPDOWN_INVENTORY",
              "options": [
                {
                  "value": "Priclys Feather",
                  "label": "Priclys Feather",
                  "next": "0209"
                }
              ],
              "otherNext": "0208"
            }
          ],
          "condition": {}
        },
        "0206": {
          "id": "0206",
          "picture": "merchant-reading-list",
          "speaker": "Merchant",
          "text": "So if you could get me a Blobfish I would be happy. Bye bye.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "0210"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            },
            {
              "type": "START_QUEST",
              "data": "Get Blobfish for Merchant"
            }
          ],
          "condition": {}
        },
        "0207": {
          "id": "0207",
          "picture": "merchant-offers-sweets",
          "speaker": "Merchant",
          "text": "Here are some sweets for ya! You've got some spare time?",
          "buttons": [
            {
              "index": 1,
              "label": "No I gotta go",
              "next": "0201"
            },
            {
              "index": 2,
              "label": "Yeah",
              "next": "0206"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            },
            {
              "type": "REMOVE_ITEM",
              "data": "Gold Coin"
            },
            {
              "type": "ADD_ITEM",
              "data": "Sweets"
            },
            {
              "type": "RESET_COUNTER",
              "item": "Sweets",
              "data": "eatAttempts"
            }
          ],
          "condition": {}
        },
        "0208": {
          "id": "0208",
          "speaker": "Merchant",
          "text": "I don't need that!",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "0201"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            }
          ],
          "condition": {}
        },
        "0209": {
          "id": "0209",
          "picture": "merchant-offers-scroll",
          "speaker": "Merchant",
          "text": "Here is the old scroll. You've got some spare time?",
          "buttons": [
            {
              "index": 1,
              "label": "No I gotta go",
              "next": "0201"
            },
            {
              "index": 2,
              "label": "Yeah",
              "next": "0206"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            },
            {
              "type": "REMOVE_ITEM",
              "data": "Priclys Feather"
            },
            {
              "type": "ADD_ITEM",
              "data": "Old Scroll"
            }
          ],
          "condition": {}
        },
        "0210": {
          "id": "0210",
          "speaker": "Merchant",
          "text": "Do you have my fish?",
          "buttons": [
            {
              "index": 1,
              "label": "No",
              "next": "0211"
            },
            {
              "index": 2,
              "label": "Yes",
              "next": "0212"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "0211": {
          "id": "0211",
          "speaker": "Merchant",
          "text": "At least you wanna buy something?",
          "buttons": [
            {
              "index": 1,
              "label": "No I gotta go",
              "next": "0201"
            },
            {
              "index": 2,
              "label": "Yup",
              "next": "0202"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            }
          ],
          "condition": {}
        },
        "0212": {
          "id": "0212",
          "picture": "merchant-asking-hand",
          "speaker": "Merchant",
          "text": "Can you give them to me?",
          "buttons": [
            {
              "index": 1,
              "label": "Choose Item",
              "next": "0213"
            }
          ],
          "actions": [
            {
              "type": "DROPDOWN_INVENTORY",
              "options": [
                {
                  "value": "Blobfish",
                  "label": "Blobfish",
                  "next": "0213"
                }
              ],
              "otherNext": "0208"
            }
          ],
          "condition": {}
        },
        "0213": {
          "id": "0213",
          "speaker": "Merchant",
          "text": "Okay. Nice. I don't have much to share but I can tell you that at the troll's riddle the letters connect to numbers somehow as I heard.",
          "buttons": [
            {
              "index": 1,
              "label": "Bye",
              "next": "0201"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            },
            {
              "type": "REMOVE_ITEM",
              "data": "Blobfish"
            },
            {
              "type": "COMPLETE_QUEST",
              "data": "Get Blobfish for Merchant"
            },
            {
              "type": "ADD_KNOWLEDGE",
              "data": "troll_letters_are_numbers"
            }
          ],
          "condition": {}
        },
        "0214": {
          "id": "0214",
          "speaker": "Merchant",
          "text": "Okay then do your tasks!",
          "buttons": [
            {
              "index": 1,
              "label": "Okay",
              "next": "0201"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            }
          ],
          "condition": {}
        },
        "0215": {
          "id": "0215",
          "speaker": "Merchant",
          "text": "Sorry but I don't have anything to sell for you now.",
          "buttons": [
            {
              "index": 1,
              "label": "Okay Bye",
              "next": "0201"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            }
          ],
          "condition": {}
        }
      }
    },
    "03": {
      "defaultPicture": "guard",
      "startPage": "0301",
      "pages": {
        "0301": {
          "id": "0301",
          "speaker": "Guard",
          "text": "Hello, boy. Are you interested in how this whole world works?",
          "buttons": [
            {
              "index": 1,
              "label": "Yes",
              "next": "0302"
            },
            {
              "index": 2,
              "label": "No just wandering",
              "next": "0303"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "0302": {
          "id": "0302",
          "picture": "guard-map-village-center",
          "speaker": "Guard",
          "text": "So let me tell you! This place is made up of different sections. We are in the Village Centre. There are 3 other sections...",
          "buttons": [
            {
              "index": 1,
              "label": "What are they?",
              "next": "0304"
            },
            {
              "index": 2,
              "label": "That's enough",
              "next": "0306"
            }
          ],
          "actions": [
            {
              "type": "ADD_KNOWLEDGE",
              "data": "village_centre"
            }
          ],
          "condition": {}
        },
        "0303": {
          "id": "0303",
          "speaker": "Guard",
          "text": "And do you know where you are?",
          "buttons": [
            {
              "index": 1,
              "label": "Not really",
              "next": "0302"
            },
            {
              "index": 2,
              "label": "Yes",
              "next": "0306"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "0304": {
          "id": "0304",
          "picture": "guard-map-sections",
          "speaker": "Guard",
          "text": "The Grove, Bridge, and the Castle Entrance. At each section there are one or more people to talk with. You can get to each part easily but the castle is guarded by the Troll.",
          "buttons": [
            {
              "index": 1,
              "label": "Who?",
              "next": "0305"
            },
            {
              "index": 2,
              "label": "I don't need more!",
              "next": "0306"
            }
          ],
          "actions": [
            {
              "type": "ADD_KNOWLEDGE",
              "data": "other_world_sections"
            },
            {
              "type": "ADD_KNOWLEDGE",
              "data": "castle_guarded_by_troll"
            }
          ],
          "condition": {}
        },
        "0305": {
          "id": "0305",
          "picture": "guard-troll-sketch",
          "speaker": "Guard",
          "text": "A troll. If you defeat it only then you can reach the entrance. But that's anything I could tell you. Have a fun time here!",
          "buttons": [
            {
              "index": 1,
              "label": "Bye",
              "next": "0307"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            },
            {
              "type": "ADD_KNOWLEDGE",
              "data": "troll_blocks_castle"
            }
          ],
          "condition": {}
        },
        "0306": {
          "id": "0306",
          "speaker": "Guard",
          "text": "Then I have nothing more to tell you.",
          "buttons": [
            {
              "index": 1,
              "label": "Bye",
              "next": "0307"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            }
          ],
          "condition": {}
        },
        "0307": {
          "id": "0307",
          "speaker": "Guard",
          "text": "Hi! Keep on exploring!",
          "buttons": [
            {
              "index": 1,
              "label": "Bye",
              "next": "0307"
            },
            {
              "index": 2,
              "label": "I have something for you",
              "next": "0308"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            }
          ],
          "condition": {
            "2": "save.inventory.includes(\"Golden Medal\")"
          }
        },
        "0308": {
          "id": "0308",
          "speaker": "Guard",
          "text": "Choose an item from your inventory.",
          "buttons": [
            {
              "index": 1,
              "label": "Choose Item",
              "next": "0310"
            }
          ],
          "actions": [
            {
              "type": "DROPDOWN_INVENTORY",
              "options": [
                {
                  "value": "Golden Medal",
                  "label": "Golden Medal",
                  "next": "0310"
                }
              ],
              "otherNext": "0309"
            }
          ],
          "condition": {}
        },
        "0309": {
          "id": "0309",
          "speaker": "Guard",
          "text": "I don't need this.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "0307"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            }
          ],
          "condition": {}
        },
        "0310": {
          "id": "0310",
          "picture": "guard-delighted",
          "speaker": "Guard",
          "text": "Oh my medal! Thank you for giving it back. For this I'll give you the Mark of Goblins. Goblins will be friendlier if you show them. Now thank you again!!!",
          "buttons": [
            {
              "index": 1,
              "label": "Bye",
              "next": "0307"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            },
            {
              "type": "REMOVE_ITEM",
              "data": "Golden Medal"
            },
            {
              "type": "ADD_ITEM",
              "data": "Mark of Goblins"
            },
            {
              "type": "COMPLETE_QUEST",
              "data": "Return Golden Medal to Guard"
            },
            {
              "type": "ADD_KNOWLEDGE",
              "data": "mark_of_goblins"
            }
          ],
          "condition": {}
        }
      }
    },
    "04": {
      "defaultPicture": "talking-tree",
      "startPage": "0401",
      "pages": {
        "0401": {
          "id": "0401",
          "speaker": "Talking Tree",
          "text": "Hello Human! What are you seeking here?",
          "buttons": [
            {
              "index": 1,
              "label": "You can TALK??",
              "next": "0402"
            },
            {
              "index": 2,
              "label": "Just rumours about people",
              "next": "0403"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "0402": {
          "id": "0402",
          "speaker": "Talking Tree",
          "text": "I'm pleased you asked although I won't share...",
          "buttons": [
            {
              "index": 1,
              "label": "Wait and talk later",
              "next": "0404"
            },
            {
              "index": 2,
              "label": "Leave now",
              "next": "0407"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            }
          ],
          "condition": {}
        },
        "0403": {
          "id": "0403",
          "speaker": "Talking Tree",
          "text": "I know things about people. I can tell you things. Who are you interested in?",
          "buttons": [
            {
              "index": 1,
              "label": "Messenger",
              "next": "0405"
            },
            {
              "index": 2,
              "label": "Warrior",
              "next": "0406"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "0404": {
          "id": "0404",
          "speaker": "Talking Tree",
          "text": "I'll soon go asleep for like 20 mins maybe. After that we can talk again.",
          "buttons": [
            {
              "index": 1,
              "label": "Bye",
              "next": "0409"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            },
            {
              "type": "START_TIMER",
              "raw": "20 minutes",
              "durationMs": 1200000
            }
          ],
          "condition": {}
        },
        "0405": {
          "id": "0405",
          "speaker": "Talking Tree",
          "text": "That guy really has a sweet tooth. Also he hates running surprisingly! Now I'm going to sleep.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "0408"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            },
            {
              "type": "ADD_KNOWLEDGE",
              "data": "messenger_personality"
            }
          ],
          "condition": {}
        },
        "0406": {
          "id": "0406",
          "speaker": "Talking Tree",
          "text": "That one is a mighty fighter and can only be defeated with the Sword of Koji. Now I shall rest.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "0408"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            },
            {
              "type": "ADD_KNOWLEDGE",
              "data": "warrior_weakness"
            }
          ],
          "condition": {}
        },
        "0407": {
          "id": "0407",
          "picture": "talking-tree-magic-branch",
          "speaker": "Talking Tree",
          "text": "At least I can give you this magic branch that will help you on your mission. I insist. Now I'm going to rest.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "0408"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            },
            {
              "type": "ADD_ITEM",
              "data": "Magic Branch"
            }
          ],
          "condition": {}
        },
        "0408": {
          "id": "0408",
          "speaker": "Talking Tree",
          "text": "The tree is asleep.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "0408"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            }
          ],
          "condition": {}
        },
        "0409": {
          "id": "0409",
          "picture": "talking-tree-horn-hole",
          "speaker": "Talking Tree",
          "text": "Hello again. I remember you were so surprised to see a wonderful tree like me. Because of that I give you the Horn of Trees. If you blow it I will wake up from my dream. And now how can I help you?",
          "buttons": [
            {
              "index": 1,
              "label": "Some info",
              "next": "0403"
            },
            {
              "index": 2,
              "label": "I don't know",
              "next": "0407"
            }
          ],
          "actions": [
            {
              "type": "ADD_ITEM",
              "data": "Horn of Trees"
            }
          ],
          "condition": {}
        },
        "0410": {
          "id": "0410",
          "speaker": "Talking Tree",
          "text": "Hello again. I can tell you things about some people.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "0403"
            },
            {
              "index": 2,
              "label": "No",
              "next": "0408"
            }
          ],
          "actions": [],
          "condition": {}
        }
      }
    },
    "05": {
      "defaultPicture": "hunter",
      "startPage": "0501",
      "pages": {
        "0501": {
          "id": "0501",
          "speaker": "Hunter",
          "text": "Greetings traveler! I'm in a hurry but I can give you a few minutes.",
          "buttons": [
            {
              "index": 1,
              "label": "Why are you hurrying?",
              "next": "0502"
            },
            {
              "index": 2,
              "label": "Who are you?",
              "next": "0503"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "0502": {
          "id": "0502",
          "speaker": "Hunter",
          "text": "I'm always in a hurry hunting for the unique species that are attracted to this grove.",
          "buttons": [
            {
              "index": 1,
              "label": "Why are they attracted?",
              "next": "0504"
            },
            {
              "index": 2,
              "label": "Who are you?",
              "next": "0503"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "0503": {
          "id": "0503",
          "speaker": "Hunter",
          "text": "I am the hunter who hunts for the species hidden in this special grove!",
          "buttons": [
            {
              "index": 1,
              "label": "Why is this grove special?",
              "next": "0504"
            },
            {
              "index": 2,
              "label": "Can I ask a question?",
              "next": "0505"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "0504": {
          "id": "0504",
          "picture": "hunter-points-trees",
          "speaker": "Hunter",
          "text": "I don't know, but I swear there is something magical hidden in this grove. You should check the trees! And now I gotta go!",
          "buttons": [
            {
              "index": 1,
              "label": "Bye",
              "next": "0506"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            },
            {
              "type": "START_TIMER",
              "raw": "5 minutes",
              "durationMs": 300000
            },
            {
              "type": "ADD_KNOWLEDGE",
              "data": "grove_magic"
            }
          ],
          "condition": {}
        },
        "0505": {
          "id": "0505",
          "speaker": "Hunter",
          "text": "Yes, but I might not know the answer.",
          "buttons": [
            {
              "index": 1,
              "label": "How do I get into the castle?",
              "next": "0504"
            },
            {
              "index": 2,
              "label": "Where is the Sword?",
              "next": "0504"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "0506": {
          "id": "0506",
          "picture": "hunter-points-fountain",
          "speaker": "Hunter",
          "text": "Hello again! I'm chasing a Pina Coala, I've got no time, but I saw something shiny between the fountain stones.",
          "buttons": [
            {
              "index": 1,
              "label": "Bye",
              "next": "0507"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            },
            {
              "type": "START_TIMER",
              "raw": "5 minutes",
              "durationMs": 300000
            },
            {
              "type": "ADD_KNOWLEDGE",
              "data": "fountain_shiny_object"
            }
          ],
          "condition": {}
        },
        "0507": {
          "id": "0507",
          "speaker": "Hunter",
          "text": "Hello adventurer! I'm back from my hunt and now I can answer a few questions, but first...",
          "buttons": [
            {
              "index": 1,
              "label": "Go on",
              "next": "0509"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "0508": {
          "id": "0508",
          "speaker": "Hunter",
          "text": "The hunter is nowhere to be seen.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "0508"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            }
          ],
          "condition": {}
        },
        "0509": {
          "id": "0509",
          "picture": "hunter-points-footprints",
          "speaker": "Hunter",
          "text": "Do you see the little footprints? That creature is better at hiding than anything else I've ever seen before. He might be hiding in one of the bushy places where I can't fit in!",
          "buttons": [
            {
              "index": 1,
              "label": "Go on",
              "next": "0510"
            }
          ],
          "actions": [
            {
              "type": "ADD_KNOWLEDGE",
              "data": "creature_in_bushes"
            }
          ],
          "condition": {}
        },
        "0510": {
          "id": "0510",
          "speaker": "Hunter",
          "text": "But now let's see your questions.",
          "buttons": [
            {
              "index": 1,
              "label": "Have you seen anything strange?",
              "next": "0511"
            },
            {
              "index": 2,
              "label": "Do you know someone here?",
              "next": "0512"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "0511": {
          "id": "0511",
          "speaker": "Hunter",
          "text": "Well, at the bridge I saw strange carvings in the stone, but nothing else.",
          "buttons": [
            {
              "index": 1,
              "label": "Thanks",
              "next": "0514"
            }
          ],
          "actions": [
            {
              "type": "ADD_KNOWLEDGE",
              "data": "bridge_carvings"
            }
          ],
          "condition": {}
        },
        "0512": {
          "id": "0512",
          "speaker": "Hunter",
          "text": "Well, have you seen the city guard? He is a friend of mine. He will tell you things about this little empire!",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "0513"
            }
          ],
          "actions": [
            {
              "type": "ADD_KNOWLEDGE",
              "data": "guard_knows_world"
            }
          ],
          "condition": {}
        },
        "0513": {
          "id": "0513",
          "picture": "hunter-gives-medal",
          "speaker": "Hunter",
          "text": "Also could you please give this golden medal to the guard? He might give you something in exchange.",
          "buttons": [
            {
              "index": 1,
              "label": "That's it?",
              "next": "0514"
            }
          ],
          "actions": [
            {
              "type": "ADD_ITEM",
              "data": "Golden Medal"
            },
            {
              "type": "START_QUEST",
              "data": "Return Golden Medal to Guard"
            }
          ],
          "condition": {}
        },
        "0514": {
          "id": "0514",
          "speaker": "Hunter",
          "text": "Okay and... Do you hear those wolves? This is the night of the blood moon, I shall go hunting, this is the time for the best prey!",
          "buttons": [
            {
              "index": 1,
              "label": "Bye",
              "next": "0508"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            }
          ],
          "condition": {}
        }
      }
    },
    "06": {
      "defaultPicture": "goblin",
      "startPage": "0601",
      "pages": {
        "0601": {
          "id": "0601",
          "speaker": "Goblin",
          "text": "Hello, who are you? I'm the goblin living in the forest. I'm glad we met.",
          "buttons": [
            {
              "index": 1,
              "label": "Hello!",
              "next": "0602"
            },
            {
              "index": 2,
              "label": "Do you have items?",
              "next": "0603"
            },
            {
              "index": 3,
              "label": "Look what I have",
              "next": "0604"
            }
          ],
          "actions": [],
          "condition": {
            "3": "save.inventory.includes(\"Mark of Goblins\")"
          }
        },
        "0602": {
          "id": "0602",
          "speaker": "Goblin",
          "text": "Hello, come with me! Let me show you my collection!",
          "buttons": [
            {
              "index": 1,
              "label": "Maybe next time",
              "next": "0605"
            },
            {
              "index": 2,
              "label": "OK",
              "next": "0606"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            }
          ],
          "condition": {}
        },
        "0603": {
          "id": "0603",
          "speaker": "Goblin",
          "text": "Yesss. Definitely. I have a collection of rare items I'm pretty proud of!",
          "buttons": [
            {
              "index": 1,
              "label": "Next time I'll see",
              "next": "0605"
            },
            {
              "index": 2,
              "label": "Show me",
              "next": "0606"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            }
          ],
          "condition": {}
        },
        "0604": {
          "id": "0604",
          "speaker": "Goblin",
          "text": "Oh you've got the Mark of Goblins. Let me gift you something my friend!",
          "buttons": [
            {
              "index": 1,
              "label": "Thank you!",
              "next": "0608"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "0605": {
          "id": "0605",
          "speaker": "Goblin",
          "text": "Hi again! May I show you my collection this time?",
          "buttons": [
            {
              "index": 1,
              "label": "Next time",
              "next": "0605"
            },
            {
              "index": 2,
              "label": "Yes",
              "next": "0606"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            }
          ],
          "condition": {}
        },
        "0606": {
          "id": "0606",
          "picture": "goblin-items-on-ground",
          "speaker": "Goblin",
          "text": "Here! Look what I've collected! If you want one just say!",
          "buttons": [
            {
              "index": 1,
              "label": "Gold Coin",
              "next": "0607"
            },
            {
              "index": 2,
              "label": "Ruby Sword",
              "next": "0609"
            },
            {
              "index": 3,
              "label": "Powder",
              "next": "0610"
            },
            {
              "index": 4,
              "label": "I don't need more",
              "next": "0616"
            }
          ],
          "actions": [],
          "condition": {
            "1": "!had_item.includes(\"Gold Coin\")",
            "2": "!had_item.includes(\"Ruby Sword\")",
            "3": "!had_item.includes(\"Strange Powder\")",
            "4": "[\"Strange Powder\", \"Ruby Sword\", \"Gold Coin\"].filter(item => had_item.includes(item)).length >= 2"
          }
        },
        "0607": {
          "id": "0607",
          "picture": "goblin-holds-gold-coin",
          "speaker": "Goblin",
          "text": "This is a Gold Coin I found in the forest. I would trade it for something from a rare animal like a bird.",
          "buttons": [
            {
              "index": 1,
              "label": "Okay, bye",
              "next": "0605"
            },
            {
              "index": 2,
              "label": "I have that",
              "next": "0611"
            },
            {
              "index": 3,
              "label": "Let me see the other items",
              "next": "0606"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            },
            {
              "type": "ADD_KNOWLEDGE",
              "data": "goblin_gold_coin_trade"
            }
          ],
          "condition": {}
        },
        "0608": {
          "id": "0608",
          "picture": "goblin-holds-lucky-pebble",
          "speaker": "Goblin",
          "text": "Here! Take this lucky pebble.",
          "buttons": [
            {
              "index": 1,
              "label": "Thx bye",
              "next": "0605"
            },
            {
              "index": 2,
              "label": "Do you have something else?",
              "next": "0606"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            },
            {
              "type": "ADD_ITEM",
              "data": "Lucky Pebble"
            }
          ],
          "condition": {}
        },
        "0609": {
          "id": "0609",
          "picture": "goblin-holds-ruby-sword",
          "speaker": "Goblin",
          "text": "This ruby sword was down in the bottom of the river. I saw its ruby and I had to have it. If you want it give me some other gem.",
          "buttons": [
            {
              "index": 1,
              "label": "Okay, bye",
              "next": "0605"
            },
            {
              "index": 2,
              "label": "I have that",
              "next": "0611"
            },
            {
              "index": 3,
              "label": "Let me see the other items",
              "next": "0606"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            },
            {
              "type": "ADD_KNOWLEDGE",
              "data": "goblin_ruby_sword_trade"
            }
          ],
          "condition": {}
        },
        "0610": {
          "id": "0610",
          "picture": "goblin-holds-powder-sack",
          "speaker": "Goblin",
          "text": "Hey I've found this powder in a leather sack and I thought it was really strange so I kept it. I would trade it for a shinier jewel.",
          "buttons": [
            {
              "index": 1,
              "label": "Okay, bye",
              "next": "0605"
            },
            {
              "index": 2,
              "label": "I have that",
              "next": "0611"
            },
            {
              "index": 3,
              "label": "Let me see the other items",
              "next": "0606"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            },
            {
              "type": "ADD_KNOWLEDGE",
              "data": "goblin_powder_trade"
            }
          ],
          "condition": {}
        },
        "0611": {
          "id": "0611",
          "picture": "goblin-empty-hand",
          "speaker": "Goblin",
          "text": "Show me!",
          "buttons": [
            {
              "index": 1,
              "label": "Choose Item",
              "next": "0612"
            }
          ],
          "actions": [
            {
              "type": "DROPDOWN_INVENTORY",
              "options": [
                {
                  "value": "Silver Ring",
                  "label": "Silver Ring",
                  "next": "0612"
                },
                {
                  "value": "Crystal Shard",
                  "label": "Crystal Shard",
                  "next": "0613"
                },
                {
                  "value": "Priclys Feather",
                  "label": "Priclys Feather",
                  "next": "0614"
                }
              ],
              "otherNext": "0615"
            }
          ],
          "condition": {}
        },
        "0612": {
          "id": "0612",
          "picture": "goblin-holds-powder-sack",
          "speaker": "Goblin",
          "text": "Here is the strange powder. I like shinies, human, like dust... It's good for goblins!",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "0605"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            },
            {
              "type": "REMOVE_ITEM",
              "data": "Silver Ring"
            },
            {
              "type": "ADD_ITEM",
              "data": "Strange Powder"
            }
          ],
          "condition": {}
        },
        "0613": {
          "id": "0613",
          "picture": "goblin-holds-ruby-sword",
          "speaker": "Goblin",
          "text": "Here is the ruby sword. I like Crystal Shard better: It's shinier.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "0605"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            },
            {
              "type": "REMOVE_ITEM",
              "data": "Crystal Shard"
            },
            {
              "type": "ADD_ITEM",
              "data": "Ruby Sword"
            }
          ],
          "condition": {}
        },
        "0614": {
          "id": "0614",
          "picture": "goblin-holds-gold-coin",
          "speaker": "Goblin",
          "text": "Here is the gold coin. Feather might be trash for humans but treasure for goblins!",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "0605"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            },
            {
              "type": "REMOVE_ITEM",
              "data": "Priclys Feather"
            },
            {
              "type": "ADD_ITEM",
              "data": "Gold Coin"
            }
          ],
          "condition": {}
        },
        "0615": {
          "id": "0615",
          "speaker": "Goblin",
          "text": "I don't need THAT!",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "0605"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            }
          ],
          "condition": {}
        },
        "0616": {
          "id": "0616",
          "picture": "goblin-holds-staff-of-goblins",
          "speaker": "Goblin",
          "text": "Can I give you one more gift for being my great trader mate? Here is the Staff of Goblins. This means you are the great friend of goblins.",
          "buttons": [
            {
              "index": 1,
              "label": "Thx",
              "next": "0617"
            }
          ],
          "actions": [
            {
              "type": "ADD_ITEM",
              "data": "Staff of Goblins"
            }
          ],
          "condition": {}
        },
        "0617": {
          "id": "0617",
          "speaker": "Goblin",
          "text": "Now I'm leaving because all treasure here is inside my pockets!",
          "buttons": [
            {
              "index": 1,
              "label": "Bye",
              "next": "0618"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            }
          ],
          "condition": {}
        },
        "0618": {
          "id": "0618",
          "picture": "goblin-tent-by-tree",
          "speaker": "Goblin",
          "text": "The goblin has left with all their valuables.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "0618"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            }
          ],
          "condition": {}
        }
      }
    },
    "07": {
      "defaultPicture": "troll",
      "startPage": "0701",
      "pages": {
        "0701": {
          "id": "0701",
          "speaker": "Troll",
          "text": "You try cross bridge?",
          "buttons": [
            {
              "index": 1,
              "label": "Yes",
              "next": "0702"
            },
            {
              "index": 2,
              "label": "No",
              "next": "0703"
            },
            {
              "index": 3,
              "label": "What??",
              "next": "0704"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "0702": {
          "id": "0702",
          "speaker": "Troll",
          "text": "You first solve me riddle!",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "0705"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "0703": {
          "id": "0703",
          "picture": "troll-blocks-bridge",
          "speaker": "Troll",
          "text": "You can no cross if no riddle solve. I tell you riddle.",
          "buttons": [
            {
              "index": 1,
              "label": "Tell me",
              "next": "0705"
            },
            {
              "index": 2,
              "label": "Let me try",
              "next": "0701"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "0704": {
          "id": "0704",
          "speaker": "Troll",
          "text": "You stupid",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "0701"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            }
          ],
          "condition": {}
        },
        "0705": {
          "id": "0705",
          "speaker": "Troll",
          "text": "First 6 letters: O, T, T, F, F, S... What's next 2?",
          "buttons": [
            {
              "index": 1,
              "label": "Choose answer",
              "next": "0706"
            }
          ],
          "actions": [
            {
              "type": "DROPDOWN_CHOICE",
              "options": [
                {
                  "label": "SE",
                  "next": "0706"
                },
                {
                  "label": "EF",
                  "next": "0704"
                },
                {
                  "label": "ST",
                  "next": "0704"
                },
                {
                  "label": "TS",
                  "next": "0704"
                },
                {
                  "label": "ET",
                  "next": "0704"
                },
                {
                  "label": "FS",
                  "next": "0704"
                }
              ]
            },
            {
              "type": "ADD_KNOWLEDGE",
              "data": "troll_riddle"
            }
          ],
          "condition": {}
        },
        "0706": {
          "id": "0706",
          "picture": "troll-holds-key",
          "speaker": "Troll",
          "text": "You smart! Here bridge key. Now go!",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "0707"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            },
            {
              "type": "ADD_ITEM",
              "data": "Bridge Key"
            }
          ],
          "condition": {}
        },
        "0707": {
          "id": "0707",
          "picture": "troll-sits-by-bridge",
          "speaker": "Troll",
          "text": "The Troll sits at the edge of the bridge and does not care about you.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "0707"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            }
          ],
          "condition": {}
        }
      }
    },
    "08": {
      "defaultPicture": "fisherman",
      "startPage": "0801",
      "pages": {
        "0801": {
          "id": "0801",
          "speaker": "Fisherman",
          "text": "Hello! What are you doing at the river?",
          "buttons": [
            {
              "index": 1,
              "label": "Just exploring",
              "next": "0803"
            },
            {
              "index": 2,
              "label": "Searching for the bridge",
              "next": "0802"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "0802": {
          "id": "0802",
          "picture": "fisherman-points-direction",
          "speaker": "Fisherman",
          "text": "Walk a few meters and turn right; the bridge is right there. Beware of the Troll. Also, could you help me with something?",
          "buttons": [
            {
              "index": 1,
              "label": "Of course",
              "next": "0804"
            },
            {
              "index": 2,
              "label": "Not now",
              "next": "0805"
            }
          ],
          "actions": [
            {
              "type": "ADD_KNOWLEDGE",
              "data": "bridge_direction"
            }
          ],
          "condition": {}
        },
        "0803": {
          "id": "0803",
          "speaker": "Fisherman",
          "text": "You should go to the river. The troll is stopping you but his riddle is not that hard.",
          "buttons": [
            {
              "index": 1,
              "label": "Okay I'll go",
              "next": "0805"
            },
            {
              "index": 2,
              "label": "What are you doing here?",
              "next": "0806"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "0804": {
          "id": "0804",
          "picture": "fisherman-gives-rod",
          "speaker": "Fisherman",
          "text": "Here is a fishing rod. Take it and throw it in. Try catching great salmon. They usually come after 20-25 seconds.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "0807"
            },
            {
              "index": 2,
              "label": "What about a blobfish?",
              "next": "0817"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            },
            {
              "type": "ADD_ITEM",
              "data": "Fishing Rod"
            },
            {
              "type": "START_QUEST",
              "data": "Get Great Salmon"
            },
            {
              "type": "ADD_KNOWLEDGE",
              "data": "great_salmon_time"
            }
          ],
          "condition": {}
        },
        "0805": {
          "id": "0805",
          "speaker": "Fisherman",
          "text": "Then I'll see you next time.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "0808"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            }
          ],
          "condition": {}
        },
        "0806": {
          "id": "0806",
          "speaker": "Fisherman",
          "text": "I'm fishing patiently trying to catch a great salmon but I can only find small fish in this muddy river.",
          "buttons": [
            {
              "index": 1,
              "label": "Can I help you?",
              "next": "0804"
            },
            {
              "index": 2,
              "label": "That is sad",
              "next": "0809"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "0807": {
          "id": "0807",
          "speaker": "Fisherman",
          "text": "Do you have the great salmon?",
          "buttons": [
            {
              "index": 1,
              "label": "Yes",
              "next": "0810"
            },
            {
              "index": 2,
              "label": "No",
              "next": "0811"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "0808": {
          "id": "0808",
          "speaker": "Fisherman",
          "text": "Hello what brought you here?",
          "buttons": [
            {
              "index": 1,
              "label": "Just exploring",
              "next": "0803"
            },
            {
              "index": 2,
              "label": "I wanna help you",
              "next": "0804"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "0809": {
          "id": "0809",
          "speaker": "Fisherman",
          "text": "I can do nothing with. Try again. Can you help me in catching the prey?",
          "buttons": [
            {
              "index": 1,
              "label": "Yes",
              "next": "0804"
            },
            {
              "index": 2,
              "label": "No",
              "next": "0805"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "0810": {
          "id": "0810",
          "picture": "fisherman-empty-hand",
          "speaker": "Fisherman",
          "text": "Then give it to me.",
          "buttons": [
            {
              "index": 1,
              "label": "Choose Item",
              "next": "0812"
            }
          ],
          "actions": [
            {
              "type": "DROPDOWN_INVENTORY",
              "options": [
                {
                  "value": "Great Salmon",
                  "label": "Great Salmon",
                  "next": "0812"
                }
              ],
              "otherNext": "0813"
            }
          ],
          "condition": {}
        },
        "0811": {
          "id": "0811",
          "speaker": "Fisherman",
          "text": "Have them next time!",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "0807"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            }
          ],
          "condition": {}
        },
        "0812": {
          "id": "0812",
          "speaker": "Fisherman",
          "text": "In return I can tell you that the Troll's \"o\" means \"one\".",
          "buttons": [
            {
              "index": 1,
              "label": "Thanks",
              "next": "0814"
            },
            {
              "index": 2,
              "label": "Can I help you?",
              "next": "0815"
            }
          ],
          "actions": [
            {
              "type": "REMOVE_ITEM",
              "data": "Great Salmon"
            },
            {
              "type": "ADD_KNOWLEDGE",
              "data": "troll_o_means_one"
            }
          ],
          "condition": {}
        },
        "0813": {
          "id": "0813",
          "speaker": "Fisherman",
          "text": "That's not the great salmon.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "0811"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            }
          ],
          "condition": {}
        },
        "0814": {
          "id": "0814",
          "speaker": "Fisherman",
          "text": "Bye bye. Now do not disturb me again in fishing!",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "0816"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            }
          ],
          "condition": {}
        },
        "0815": {
          "id": "0815",
          "picture": "fisherman-gives-small-fish",
          "speaker": "Fisherman",
          "text": "Well... if you could give this to the messenger... and return of a favor please give these fish to him. He might tell you something.",
          "buttons": [
            {
              "index": 1,
              "label": "I'll give it to him",
              "next": "0814"
            }
          ],
          "actions": [
            {
              "type": "ADD_ITEM",
              "data": "Fish"
            },
            {
              "type": "START_QUEST",
              "data": "Give Fish to Messenger"
            }
          ],
          "condition": {}
        },
        "0816": {
          "id": "0816",
          "picture": "fisherman-sits-on-dock",
          "speaker": "Fisherman",
          "text": "The fisherman waves at you and then puts the finger in front of his mouth \"shh\". You can't talk to him right now.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "0816"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            }
          ],
          "condition": {}
        },
        "0817": {
          "id": "0817",
          "speaker": "Fisherman",
          "text": "Blobfish usually catch after 12-15 seconds.",
          "buttons": [
            {
              "index": 1,
              "label": "Okay thanks",
              "next": "0807"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            },
            {
              "type": "ADD_KNOWLEDGE",
              "data": "blobfish_time"
            }
          ],
          "condition": {}
        }
      }
    },
    "09": {
      "defaultPicture": "messenger",
      "requiredArea": "CASTLE_SIDE",
      "startPage": "0901",
      "pages": {
        "0901": {
          "id": "0901",
          "speaker": "Messenger",
          "text": "Hi I am the messenger. I'm always walking around delivering messages to various people.",
          "buttons": [
            {
              "index": 1,
              "label": "Why not running?",
              "next": "0902"
            },
            {
              "index": 2,
              "label": "Can I give you something?",
              "next": "0903"
            },
            {
              "index": 3,
              "label": "You need help?",
              "next": "0904"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "0902": {
          "id": "0902",
          "speaker": "Messenger",
          "text": "Hey no I hate running. I would never run. Now if you have something important...",
          "buttons": [
            {
              "index": 1,
              "label": "Can I give you something?",
              "next": "0903"
            },
            {
              "index": 2,
              "label": "You need my help?",
              "next": "0904"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "0903": {
          "id": "0903",
          "picture": "messenger-open-gloved-hands",
          "speaker": "Messenger",
          "text": "Then give it.",
          "buttons": [
            {
              "index": 1,
              "label": "Choose Item",
              "next": "0905"
            }
          ],
          "actions": [
            {
              "type": "DROPDOWN_INVENTORY",
              "options": [
                {
                  "value": "Bundle of Letters",
                  "label": "Bundle of Letters",
                  "next": "0905"
                },
                {
                  "value": "Fish",
                  "label": "Fish",
                  "next": "0907"
                }
              ],
              "otherNext": "0913"
            }
          ],
          "condition": {}
        },
        "0904": {
          "id": "0904",
          "speaker": "Messenger",
          "text": "Well... I lost - let me count - three messages went lost when I was at the bridge's Castle side end. I dropped them. If you could bring those back I'd be happy.",
          "buttons": [
            {
              "index": 1,
              "label": "Okay I'll do",
              "next": "0906"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            },
            {
              "type": "START_QUEST",
              "data": "Lost Messages"
            }
          ],
          "condition": {}
        },
        "0905": {
          "id": "0905",
          "picture": "messenger-delighted-letters",
          "speaker": "Messenger",
          "text": "Oh thank you!!! In return I can tell you the first part of the password.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "0911"
            }
          ],
          "actions": [
            {
              "type": "REMOVE_ITEM",
              "data": "Bundle of Letters"
            },
            {
              "type": "COMPLETE_QUEST",
              "data": "Lost Messages"
            }
          ],
          "condition": {}
        },
        "0906": {
          "id": "0906",
          "speaker": "Messenger",
          "text": "Do you have those letters?",
          "buttons": [
            {
              "index": 1,
              "label": "Yes",
              "next": "0908"
            },
            {
              "index": 2,
              "label": "No",
              "next": "0909"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "0907": {
          "id": "0907",
          "picture": "messenger-delighted-fish",
          "speaker": "Messenger",
          "text": "Ooh the Fisherman sent me these fish? Nice. In return I'll tell you: if you ever find strange words on paper you should use a decoder powder which is just a gray powder. Now I gotta go.",
          "buttons": [
            {
              "index": 1,
              "label": "Bye",
              "next": "0910"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            },
            {
              "type": "REMOVE_ITEM",
              "data": "Fish"
            },
            {
              "type": "COMPLETE_QUEST",
              "data": "Give Fish to Messenger"
            },
            {
              "type": "ADD_KNOWLEDGE",
              "data": "decoder_powder"
            }
          ],
          "condition": {}
        },
        "0908": {
          "id": "0908",
          "speaker": "Messenger",
          "text": "Please give them to me. I really need them.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "0903"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "0909": {
          "id": "0909",
          "speaker": "Messenger",
          "text": "Then why did you come back? I'm in a hurry. Only come back when you have those letters.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "0906"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            }
          ],
          "condition": {}
        },
        "0910": {
          "id": "0910",
          "speaker": "Messenger",
          "text": "Hello, do you want to help me in something?",
          "buttons": [
            {
              "index": 1,
              "label": "No",
              "next": "0910"
            },
            {
              "index": 2,
              "label": "Yes",
              "next": "0904"
            },
            {
              "index": 3,
              "label": "I wanna give you something",
              "next": "0903"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            }
          ],
          "condition": {}
        },
        "0911": {
          "id": "0911",
          "speaker": "Messenger",
          "text": "The first part of the password is \"Apple\", now I gotta go!",
          "buttons": [
            {
              "index": 1,
              "label": "Thx",
              "next": "0912"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            },
            {
              "type": "ADD_KNOWLEDGE",
              "data": "password_first_part"
            }
          ],
          "condition": {}
        },
        "0912": {
          "id": "0912",
          "speaker": "Messenger",
          "text": "You can't see the messenger.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "0912"
            },
            {
              "index": 2,
              "label": "Shout for him",
              "next": "0914"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            }
          ],
          "condition": {}
        },
        "0913": {
          "id": "0913",
          "speaker": "Messenger",
          "text": "That is not what I need.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "0906"
            }
          ],
          "actions": [
            {
              "type": "NEXT_SCAN"
            }
          ],
          "condition": {}
        },
        "0914": {
          "id": "0914",
          "speaker": "Messenger",
          "text": "After a couple of minutes the messenger comes back. He is a bit angry but he is happy to see you.",
          "buttons": [
            {
              "index": 1,
              "label": "Wanna give you something",
              "next": "0903"
            }
          ],
          "actions": []
        }
      }
    }
  },
  "items": {
    "Sweets": {
      "defaultPicture": "sweets",
      "displayName": "Sweets",
      "startPage": "1101",
      "pages": {
        "1101": {
          "id": "1101",
          "speaker": "Sweets",
          "text": "These are just sweets.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "HOME"
            },
            {
              "index": 2,
              "label": "Eat them",
              "next": "1102"
            },
            {
              "index": 3,
              "label": "Eat them",
              "next": "1103"
            }
          ],
          "actions": [
            {
              "type": "ADD_COUNTER",
              "data": "eatAttempts",
              "amount": 1,
              "buttonIndex": 2
            },
            {
              "type": "ADD_COUNTER",
              "data": "eatAttempts",
              "amount": 1,
              "buttonIndex": 3
            }
          ],
          "condition": {
            "2": "counter(\"eatAttempts\") < 4",
            "3": "counter(\"eatAttempts\") >= 4"
          }
        },
        "1102": {
          "id": "1102",
          "speaker": "Sweets",
          "text": "A small warning: DON'T!",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "HOME"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "1103": {
          "id": "1103",
          "speaker": "Sweets",
          "text": "You actually ate them. Now you lost a valuable resource...\n\nJust great...",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "HOME"
            }
          ],
          "actions": [
            {
              "type": "REMOVE_ITEM",
              "data": "Sweets"
            }
          ],
          "condition": {}
        }
      }
    },
    "Old Scroll": {
      "defaultPicture": "old-scroll",
      "displayName": "Old Scroll",
      "startPage": "1201",
      "pages": {
        "1201": {
          "id": "1201",
          "speaker": "Old Scroll",
          "text": "It's just an old scroll folded up!",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "HOME"
            },
            {
              "index": 2,
              "label": "Inspect",
              "next": "1202"
            },
            {
              "index": 3,
              "label": "Unfold",
              "next": "1203"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "1202": {
          "id": "1202",
          "speaker": "Old Scroll",
          "text": "Its paper looks very old, and it's a little bit dirty.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "HOME"
            },
            {
              "index": 2,
              "label": "Unfold",
              "next": "1203"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "1203": {
          "id": "1203",
          "speaker": "Old Scroll",
          "text": "You unfold it and find a strange thing written on it:\n\nRcuuygtf:Crrmgrkg",
          "buttons": [
            {
              "index": 1,
              "label": "Inspect the paper",
              "next": "1202"
            },
            {
              "index": 2,
              "label": "Read it out",
              "next": "1204"
            },
            {
              "index": 3,
              "label": "OK",
              "next": "HOME"
            }
          ],
          "actions": [
            {
              "type": "ADD_KNOWLEDGE",
              "data": "encoded_scroll"
            }
          ],
          "condition": {}
        },
        "1204": {
          "id": "1204",
          "speaker": "Old Scroll",
          "text": "You start babbling but nothing extraordinary happens except you look like you lost your mind.",
          "buttons": [
            {
              "index": 1,
              "label": "Combine it with an item",
              "next": "1205"
            },
            {
              "index": 2,
              "label": "OK",
              "next": "HOME"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "1205": {
          "id": "1205",
          "speaker": "Old Scroll",
          "text": "Choose an item from inventory:",
          "buttons": [
            {
              "index": 1,
              "label": "Choose Item",
              "next": "1207"
            }
          ],
          "actions": [
            {
              "type": "DROPDOWN_INVENTORY",
              "options": [
                {
                  "value": "Strange Powder",
                  "label": "Strange Powder",
                  "next": "1207"
                }
              ],
              "otherNext": "1206"
            }
          ],
          "condition": {}
        },
        "1206": {
          "id": "1206",
          "speaker": "Old Scroll",
          "text": "Nothing happens.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "HOME"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "1207": {
          "id": "1207",
          "speaker": "Old Scroll",
          "text": "The words shimmer and the magic powder turns into dust and the evaporates under it you find new words.\n\nPassword:ApplePie",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "HOME"
            }
          ],
          "actions": [
            {
              "type": "ADD_ITEM",
              "data": "Scroll with Password"
            },
            {
              "type": "REMOVE_ITEM",
              "data": "Old Scroll"
            },
            {
              "type": "REMOVE_ITEM",
              "data": "Strange Powder"
            },
            {
              "type": "ADD_KNOWLEDGE",
              "data": "castle_password"
            }
          ],
          "condition": {}
        }
      }
    },
    "Magic Branch": {
      "defaultPicture": "magic-branch",
      "displayName": "Magic Branch",
      "startPage": "1301",
      "pages": {
        "1301": {
          "id": "1301",
          "speaker": "Magic Branch",
          "text": "This is a branch you've got from a talking tree.",
          "buttons": [
            {
              "index": 1,
              "label": "Swing it",
              "next": "1302"
            },
            {
              "index": 2,
              "label": "OK",
              "next": "HOME"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "1302": {
          "id": "1302",
          "speaker": "Magic Branch",
          "text": "Rainbow glitters appear but nothing else changes.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "HOME"
            }
          ],
          "actions": [],
          "condition": {}
        }
      }
    },
    "Horn of Trees": {
      "defaultPicture": "horn-of-trees",
      "displayName": "Horn of Trees",
      "startPage": "1401",
      "pages": {
        "1401": {
          "id": "1401",
          "speaker": "Horn of Trees",
          "text": "This strange horn you've got from tree. It looks like an instrument.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "HOME"
            },
            {
              "index": 2,
              "label": "Blow it",
              "next": "1402"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "1402": {
          "id": "1402",
          "speaker": "Horn of Trees",
          "text": "When you blow it you hear a voice of dried leaf rustling, and the tree speaks to you.",
          "buttons": [
            {
              "index": 1,
              "label": "Let's hear her",
              "next": "0410"
            }
          ],
          "actions": [],
          "condition": {}
        }
      },
      "crossEncounterTargets": [
        "0410"
      ]
    },
    "Bridge Key": {
      "defaultPicture": "bridge-key",
      "displayName": "Bridge Key",
      "startPage": "1501",
      "pages": {
        "1501": {
          "id": "1501",
          "speaker": "Bridge Key",
          "text": "A silver key. You can open the bridge with it.",
          "buttons": [
            {
              "index": 1,
              "label": "Use it",
              "next": "1502"
            },
            {
              "index": 2,
              "label": "OK",
              "next": "HOME"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "1502": {
          "id": "1502",
          "speaker": "Bridge Key",
          "text": "Now the bridge is open and you can access the Castle Entrance area.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "HOME"
            }
          ],
          "actions": [
            {
              "type": "UNLOCK_AREA",
              "data": "CASTLE_SIDE"
            }
          ],
          "condition": {}
        }
      }
    },
    "Golden Medal": {
      "defaultPicture": "golden-medal",
      "displayName": "Golden Medal",
      "startPage": "1601",
      "pages": {
        "1601": {
          "id": "1601",
          "speaker": "Golden Medal",
          "text": "A golden coin attached to a silk string. It was given to you by the hunter to give this to his friend the Guard, in the means of friendship.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "HOME"
            },
            {
              "index": 2,
              "label": "Give it to Guard",
              "next": "1602"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "1602": {
          "id": "1602",
          "speaker": "Golden Medal",
          "text": "Then go to the guard!!!",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "HOME"
            }
          ],
          "actions": [],
          "condition": {}
        }
      }
    },
    "Mark of Goblins": {
      "defaultPicture": "mark-of-goblins",
      "displayName": "Mark of Goblins",
      "startPage": "1701",
      "pages": {
        "1701": {
          "id": "1701",
          "speaker": "Mark of Goblins",
          "text": "A small wooden token with a goblin face carved into it. The guard believes it impresses goblins.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "HOME"
            }
          ],
          "actions": [],
          "condition": {}
        }
      }
    },
    "Priclys Feather": {
      "defaultPicture": "priclys-feather",
      "displayName": "Priclys Feather",
      "startPage": "1801",
      "pages": {
        "1801": {
          "id": "1801",
          "speaker": "Priclys Feather",
          "text": "A yellowish-brown feather dotted with white spots. It probably came from an unusual creature.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "HOME"
            },
            {
              "index": 2,
              "label": "Wave it",
              "next": "1802"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "1802": {
          "id": "1802",
          "speaker": "Priclys Feather",
          "text": "You hear the flutter of wings, then the sound slowly fades away.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "HOME"
            }
          ],
          "actions": [],
          "condition": {}
        }
      }
    },
    "Strange Powder": {
      "defaultPicture": "strange-powder",
      "displayName": "Strange Powder",
      "startPage": "1901",
      "pages": {
        "1901": {
          "id": "1901",
          "speaker": "Strange Powder",
          "text": "This powder is really strange. You could try rubbing it into something because it looks magical.",
          "buttons": [
            {
              "index": 1,
              "label": "Not now",
              "next": "HOME"
            },
            {
              "index": 2,
              "label": "Try",
              "next": "1902"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "1902": {
          "id": "1902",
          "speaker": "Strange Powder",
          "text": "Into what?",
          "buttons": [
            {
              "index": 1,
              "label": "Choose Item",
              "next": "1903"
            }
          ],
          "actions": [
            {
              "type": "DROPDOWN_INVENTORY",
              "options": [
                {
                  "value": "Old Scroll",
                  "label": "Old Scroll",
                  "next": "1903"
                }
              ],
              "otherNext": "1904"
            }
          ],
          "condition": {}
        },
        "1903": {
          "id": "1903",
          "speaker": "Strange Powder",
          "text": "When you rub it into the old paper, it shimmers and the new text appears. Password:”ApplePie”. You got the password to something.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "HOME"
            }
          ],
          "actions": [
            {
              "type": "ADD_ITEM",
              "data": "Scroll with Password"
            },
            {
              "type": "REMOVE_ITEM",
              "data": "Old Scroll"
            },
            {
              "type": "REMOVE_ITEM",
              "data": "Strange Powder"
            },
            {
              "type": "ADD_KNOWLEDGE",
              "data": "castle_password"
            }
          ],
          "condition": {}
        },
        "1904": {
          "id": "1904",
          "speaker": "Strange Powder",
          "text": "Nothing happens.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "HOME"
            }
          ],
          "actions": [],
          "condition": {}
        }
      }
    },
    "Gold Coin": {
      "defaultPicture": "gold-coin",
      "displayName": "Gold Coin",
      "startPage": "2001",
      "pages": {
        "2001": {
          "id": "2001",
          "speaker": "Gold Coin",
          "text": "A golden coin Found by the goblin, can be used for transactional. purpose.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "HOME"
            }
          ],
          "actions": [],
          "condition": {}
        }
      }
    },
    "Ruby Sword": {
      "defaultPicture": "ruby-sword",
      "displayName": "Ruby Sword",
      "startPage": "2101",
      "pages": {
        "2101": {
          "id": "2101",
          "speaker": "Ruby Sword / Sword of Koji",
          "text": "The blade looks very ancient, very unique. You are glad to have it from the goblin.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "HOME"
            },
            {
              "index": 2,
              "label": "Practice",
              "next": "2102"
            },
            {
              "index": 3,
              "label": "Throw it",
              "next": "2103"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "2102": {
          "id": "2102",
          "speaker": "Ruby Sword / Sword of Koji",
          "text": "When you hold it like a sword fighter, you feel a great strength in your veins. You try a few complicated moves. They are super easy. You became a very good fighter.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "HOME"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "2103": {
          "id": "2103",
          "speaker": "Ruby Sword / Sword of Koji",
          "text": "When you throw it, it comes back to you like a boomerang. This looks like a magical weapon.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "HOME"
            }
          ],
          "actions": [],
          "condition": {}
        }
      },
      "aliases": [
        "Sword of Koji"
      ]
    },
    "Staff of Goblins": {
      "defaultPicture": "staff-of-goblins",
      "displayName": "Staff of Goblins",
      "startPage": "2201",
      "pages": {
        "2201": {
          "id": "2201",
          "speaker": "Staff of Goblins",
          "text": "This wooden and gold staff you got from a goblin is the symbol of friendship.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "HOME"
            },
            {
              "index": 2,
              "label": "Stomp it",
              "next": "2202"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "2202": {
          "id": "2202",
          "speaker": "Staff of Goblins",
          "text": "You stomp it. You hear a fading goblin laugh, and then silence.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "HOME"
            }
          ],
          "actions": [],
          "condition": {}
        }
      }
    },
    "Fishing Rod": {
      "defaultPicture": "fishing-rod",
      "displayName": "Fishing Rod",
      "startPage": "2301",
      "pages": {
        "2301": {
          "id": "2301",
          "speaker": "Fishing Rod",
          "text": "Just a fishing rod with a small bobber.",
          "buttons": [
            {
              "index": 1,
              "label": "Throw it in",
              "next": "2302"
            },
            {
              "index": 2,
              "label": "OK",
              "next": "HOME"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "2302": {
          "id": "2302",
          "speaker": "Fishing Rod",
          "text": "You throw it in and wait two-three seconds.",
          "buttons": [
            {
              "index": 1,
              "label": "Reel",
              "next": "2310"
            },
            {
              "index": 2,
              "label": "Wait",
              "next": "2303"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "2303": {
          "id": "2303",
          "speaker": "Fishing Rod",
          "text": "You wait four-five seconds.",
          "buttons": [
            {
              "index": 1,
              "label": "Reel",
              "next": "2310"
            },
            {
              "index": 2,
              "label": "Wait",
              "next": "2304"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "2304": {
          "id": "2304",
          "speaker": "Fishing Rod",
          "text": "You wait six, seven seconds.",
          "buttons": [
            {
              "index": 1,
              "label": "Reel",
              "next": "2311"
            },
            {
              "index": 2,
              "label": "Reel",
              "next": "2310"
            },
            {
              "index": 3,
              "label": "Wait",
              "next": "2305"
            }
          ],
          "actions": [
            {
              "type": "SET_COUNTER",
              "data": "blobfishCaught",
              "value": 1,
              "buttonIndex": 1
            }
          ],
          "condition": {
            "1": "counter(\"blobfishCaught\") < 1",
            "2": "counter(\"blobfishCaught\") >= 1"
          }
        },
        "2305": {
          "id": "2305",
          "speaker": "Fishing Rod",
          "text": "You wait three, four seconds.",
          "buttons": [
            {
              "index": 1,
              "label": "Reel",
              "next": "2310"
            },
            {
              "index": 2,
              "label": "Wait",
              "next": "2306"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "2306": {
          "id": "2306",
          "speaker": "Fishing Rod",
          "text": "You wait three seconds.",
          "buttons": [
            {
              "index": 1,
              "label": "Reel",
              "next": "2310"
            },
            {
              "index": 2,
              "label": "Wait",
              "next": "2307"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "2307": {
          "id": "2307",
          "speaker": "Fishing Rod",
          "text": "You wait two, three seconds.",
          "buttons": [
            {
              "index": 1,
              "label": "Reel",
              "next": "2312"
            },
            {
              "index": 2,
              "label": "Reel",
              "next": "2310"
            },
            {
              "index": 3,
              "label": "Wait",
              "next": "2308"
            }
          ],
          "actions": [
            {
              "type": "SET_COUNTER",
              "data": "salmonCaught",
              "value": 1,
              "buttonIndex": 1
            }
          ],
          "condition": {
            "1": "counter(\"salmonCaught\") < 1",
            "2": "counter(\"salmonCaught\") >= 1"
          }
        },
        "2308": {
          "id": "2308",
          "speaker": "Fishing Rod",
          "text": "You wait four, six seconds.",
          "buttons": [
            {
              "index": 1,
              "label": "Reel",
              "next": "2310"
            },
            {
              "index": 2,
              "label": "Wait",
              "next": "2309"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "2309": {
          "id": "2309",
          "speaker": "Fishing Rod",
          "text": "You wait one more second.",
          "buttons": [
            {
              "index": 1,
              "label": "Reel",
              "next": "2313"
            },
            {
              "index": 2,
              "label": "Reel",
              "next": "2310"
            }
          ],
          "actions": [
            {
              "type": "SET_COUNTER",
              "data": "bootsCaught",
              "value": 1,
              "buttonIndex": 1
            }
          ],
          "condition": {
            "1": "counter(\"bootsCaught\") < 1",
            "2": "counter(\"bootsCaught\") >= 1"
          }
        },
        "2310": {
          "id": "2310",
          "speaker": "Fishing Rod",
          "text": "Nothing. You caught nothing. Now, you go away.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "HOME"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "2311": {
          "id": "2311",
          "speaker": "Fishing Rod",
          "text": "You struggle with the pull in, and at the end of the road, there is a blobfish.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "HOME"
            }
          ],
          "actions": [
            {
              "type": "ADD_ITEM",
              "data": "Blobfish"
            }
          ],
          "condition": {}
        },
        "2312": {
          "id": "2312",
          "speaker": "Fishing Rod",
          "text": "You start pulling it in, you struggle, and then ta-da, there is a large salmon.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "HOME"
            }
          ],
          "actions": [
            {
              "type": "ADD_ITEM",
              "data": "Great Salmon"
            },
            {
              "type": "COMPLETE_QUEST",
              "data": "Get Great Salmon"
            }
          ],
          "condition": {}
        },
        "2313": {
          "id": "2313",
          "speaker": "Fishing Rod",
          "text": "You find an old boot.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "HOME"
            }
          ],
          "actions": [
            {
              "type": "ADD_ITEM",
              "data": "Old Boots"
            }
          ],
          "condition": {}
        }
      }
    },
    "Crystal Shard": {
      "defaultPicture": "crystal-shard",
      "displayName": "Crystal Shard",
      "startPage": "2401",
      "pages": {
        "2401": {
          "id": "2401",
          "speaker": "Crystal Shard",
          "text": "A blue crystal shard. When you hold it up to the light, it scatters the light into rainbow colors.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "HOME"
            }
          ],
          "actions": [],
          "condition": {}
        }
      }
    },
    "Blobfish": {
      "defaultPicture": "blobfish",
      "displayName": "Blobfish",
      "startPage": "2501",
      "pages": {
        "2501": {
          "id": "2501",
          "speaker": "Blobfish",
          "text": "It looks just like a deflated ball.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "HOME"
            },
            {
              "index": 2,
              "label": "Inflate",
              "next": "2502"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "2502": {
          "id": "2502",
          "speaker": "Blobfish",
          "text": "You struggle and fail for a long time. Then you give up.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "HOME"
            }
          ],
          "actions": [],
          "condition": {}
        }
      }
    },
    "Silver Ring": {
      "defaultPicture": "silver-ring",
      "displayName": "Silver Ring",
      "startPage": "2601",
      "pages": {
        "2601": {
          "id": "2601",
          "speaker": "Silver Ring",
          "text": "A beautiful shining ring you found at the river.",
          "buttons": [
            {
              "index": 1,
              "label": "Put it on.",
              "next": "2602"
            },
            {
              "index": 2,
              "label": "OK",
              "next": "HOME"
            }
          ],
          "actions": [
            {
              "type": "SET_COUNTER",
              "data": "worn",
              "value": 1,
              "buttonIndex": 1
            }
          ],
          "condition": {
            "1": "counter(\"worn\") < 1"
          }
        },
        "2602": {
          "id": "2602",
          "speaker": "Silver Ring",
          "text": "You put it on your finger, and it looks good with its silvery shining.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "HOME"
            }
          ],
          "actions": [],
          "condition": {}
        }
      }
    },
    "Bundle of Letters": {
      "defaultPicture": "bundle-of-letters",
      "displayName": "Bundle of Letters",
      "startPage": "2701",
      "pages": {
        "2701": {
          "id": "2701",
          "speaker": "Bundle of Letters",
          "text": "A bundle of letters you found at the bridge dropped by someone.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "HOME"
            }
          ],
          "actions": [],
          "condition": {}
        }
      }
    },
    "Scroll with Password": {
      "defaultPicture": "scroll-with-password",
      "displayName": "Scroll with Password",
      "startPage": "2801",
      "pages": {
        "2801": {
          "id": "2801",
          "speaker": "Scroll with Password",
          "text": "It's just the old scroll, but decoded.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "HOME"
            },
            {
              "index": 2,
              "label": "Inspect",
              "next": "2802"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "2802": {
          "id": "2802",
          "speaker": "Scroll with Password",
          "text": "The words on the paper read, “password: ApplePie.” Though, where should you use it?",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "HOME"
            }
          ],
          "actions": [
            {
              "type": "ADD_KNOWLEDGE",
              "data": "castle_password"
            }
          ],
          "condition": {}
        }
      }
    },
    "Old Boots": {
      "defaultPicture": "old-boots",
      "displayName": "Old Boots",
      "startPage": "2901",
      "pages": {
        "2901": {
          "id": "2901",
          "speaker": "Old Boots",
          "text": "Just a pair of worn leather boots. Still dripping water.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "HOME"
            },
            {
              "index": 2,
              "label": "Wear",
              "next": "2902"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "2902": {
          "id": "2902",
          "speaker": "Old Boots",
          "text": "You put it on but they are so wet and uncomfortable you immediately take it off.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "HOME"
            }
          ],
          "actions": [],
          "condition": {}
        }
      }
    },
    "Great Salmon": {
      "defaultPicture": "great-salmon",
      "displayName": "Great Salmon",
      "startPage": "3001",
      "pages": {
        "3001": {
          "id": "3001",
          "speaker": "Great Salmon",
          "text": "It's just a large fish. Wait… it's still alive!",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "HOME"
            }
          ],
          "actions": [],
          "condition": {}
        }
      }
    },
    "Fish": {
      "defaultPicture": "fish",
      "displayName": "Fish",
      "startPage": "3101",
      "pages": {
        "3101": {
          "id": "3101",
          "speaker": "Fish",
          "text": "These are just fish in a bag.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "HOME"
            }
          ],
          "actions": [],
          "condition": {}
        }
      }
    },
    "Lucky Pebble": {
      "defaultPicture": "lucky-pebble",
      "displayName": "Lucky Pebble",
      "startPage": "3201",
      "pages": {
        "3201": {
          "id": "3201",
          "speaker": "Lucky Pebble",
          "text": "A small pebble that seems to bring luck.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "HOME"
            }
          ],
          "actions": [],
          "condition": {}
        }
      }
    },
    "Straw": {
      "displayName": "Straw",
      "startPage": "3601",
      "pages": {
        "3601": {
          "id": "3601",
          "speaker": "Straw",
          "text": "A bundle of straw that someone must have lost.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "HOME"
            }
          ],
          "actions": [],
          "condition": {}
        }
      },
      "defaultPicture": "straw"
    },
    "Mosquito": {
      "displayName": "Mosquito",
      "startPage": "3701",
      "pages": {
        "3701": {
          "id": "3701",
          "speaker": "Mosquito",
          "text": "A couple of mosquitoes wrapped in spiderweb.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "HOME"
            }
          ],
          "actions": [],
          "condition": {}
        }
      },
      "defaultPicture": "mosquito"
    },
    "Sketch3": {
      "displayName": "Sketch 3",
      "startPage": "3801",
      "implemented": false,
      "pages": {}
    },
    "Golden Apple": {
      "displayName": "Golden Apple",
      "startPage": "3901",
      "implemented": false,
      "pages": {}
    },
    "Magic Book": {
      "displayName": "The Magic Pebble",
      "startPage": "4001",
      "pages": {
        "4001": {
          "id": "4001",
          "speaker": "The Magic Pebble",
          "text": "A book with a glowing white pebble on its cover.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "HOME"
            },
            {
              "index": 2,
              "label": "Open it",
              "next": "4002"
            },
            {
              "index": 3,
              "label": "Open it",
              "next": "4009"
            }
          ],
          "actions": [],
          "condition": {
            "2": "save.inventory.includes(\"Magnifying Glass\")",
            "3": "!save.inventory.includes(\"Magnifying Glass\")"
          },
          "picture": "magic-book-cover"
        },
        "4002": {
          "id": "4002",
          "speaker": "The Magic Pebble",
          "text": "Once upon a time, there was a child named Márió. He had a beautiful pebble that was as smooth as a mirror.",
          "buttons": [
            {
              "index": 1,
              "label": "Next page",
              "next": "4003"
            },
            {
              "index": 2,
              "label": "Close the book",
              "next": "4001"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "4003": {
          "id": "4003",
          "speaker": "The Magic Pebble",
          "text": "Sometimes the pebble seemed as if it wandered around. Márió put it down in one place, and a little while later he found it somewhere else.",
          "buttons": [
            {
              "index": 1,
              "label": "Previous page",
              "next": "4002"
            },
            {
              "index": 2,
              "label": "Next page",
              "next": "4004"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "4004": {
          "id": "4004",
          "speaker": "The Magic Pebble",
          "text": "One day his father examined the pebble too, and with a magnifying glass he discovered strange symbols on it. The symbols seemed to be written in some ancient language.",
          "buttons": [
            {
              "index": 1,
              "label": "Previous page",
              "next": "4003"
            },
            {
              "index": 2,
              "label": "Next page",
              "next": "4005"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "4005": {
          "id": "4005",
          "speaker": "The Magic Pebble",
          "text": "They took it to Mógi, the local wizard, hoping he would know what it was. When they arrived, he was already waiting for them with a smile.",
          "buttons": [
            {
              "index": 1,
              "label": "Previous page",
              "next": "4004"
            },
            {
              "index": 2,
              "label": "Next page",
              "next": "4006"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "4006": {
          "id": "4006",
          "speaker": "The Magic Pebble",
          "text": "“Hi!” said Mógi. “May I see the pebble?”\n“Where did you—” Márió exclaimed, but Mógi interrupted him.\n“I saw you coming!”\nDad handed him the pebble. The wizard examined it and exclaimed:\n“My goodness! This is incredible!”",
          "buttons": [
            {
              "index": 1,
              "label": "Previous page",
              "next": "4005"
            },
            {
              "index": 2,
              "label": "Next page",
              "next": "4007"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "4007": {
          "id": "4007",
          "speaker": "The Magic Pebble",
          "text": "“What is it?” asked Márió.\n“It is written in an ancient magical language,” said Mógi. “If someone gives this pebble to somebody else purely out of friendship, as a gift, the person they give it to will have great luck.”",
          "buttons": [
            {
              "index": 1,
              "label": "Previous page",
              "next": "4006"
            },
            {
              "index": 2,
              "label": "Next page",
              "next": "4008"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "4008": {
          "id": "4008",
          "speaker": "The Magic Pebble",
          "text": "Márió remained lucky for the rest of his life, and whatever he tried, he succeeded at it.\n\nTHE END\nChronicler Tivadar",
          "buttons": [
            {
              "index": 1,
              "label": "Previous page",
              "next": "4007"
            },
            {
              "index": 2,
              "label": "Close the book",
              "next": "HOME"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "4009": {
          "id": "4009",
          "speaker": "The Magic Pebble",
          "text": "The letters (and the book itself) are too small for you to read with the naked eye.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "HOME"
            }
          ],
          "actions": [],
          "condition": {},
          "picture": "book-too-small"
        }
      },
      "defaultPicture": "book"
    },
    "Magnifying Glass": {
      "displayName": "Magnifying Glass",
      "startPage": "4101",
      "pages": {
        "4101": {
          "id": "4101",
          "speaker": "Magnifying Glass",
          "text": "This magnifying glass helps you inspect things you cannot see with the naked eye.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "HOME"
            },
            {
              "index": 2,
              "label": "Inspect something",
              "next": "4102"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "4102": {
          "id": "4102",
          "speaker": "Magnifying Glass",
          "text": "What?",
          "buttons": [
            {
              "index": 1,
              "label": "Choose item",
              "next": "4103"
            }
          ],
          "actions": [
            {
              "type": "DROPDOWN_INVENTORY",
              "options": [],
              "otherNext": "4103"
            }
          ],
          "condition": {}
        },
        "4103": {
          "id": "4103",
          "speaker": "Magnifying Glass",
          "text": "Now you can see the smaller details too.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "HOME"
            }
          ],
          "actions": [],
          "condition": {}
        }
      },
      "defaultPicture": "magnifier-card"
    },
    "Premium Library Card": {
      "displayName": "Premium Library Card",
      "startPage": "4201",
      "pages": {
        "4201": {
          "id": "4201",
          "speaker": "Premium Library Card",
          "text": "This gives you unlimited access to the library books!",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "HOME"
            }
          ],
          "actions": [],
          "condition": {}
        }
      },
      "defaultPicture": "premium-library-card"
    },
    "Worm Book": {
      "displayName": "The History of the Worms",
      "startPage": "4301",
      "pages": {
        "4301": {
          "id": "4301",
          "speaker": "The History of the Worms",
          "text": "A book showing worms dressed in all kinds of different outfits.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "HOME"
            },
            {
              "index": 2,
              "label": "Open it",
              "next": "4302"
            },
            {
              "index": 3,
              "label": "Open it",
              "next": "4309"
            }
          ],
          "actions": [],
          "condition": {
            "2": "save.inventory.includes(\"Magnifying Glass\")",
            "3": "!save.inventory.includes(\"Magnifying Glass\")"
          },
          "picture": "worm-book-cover"
        },
        "4302": {
          "id": "4302",
          "speaker": "The History of the Worms",
          "text": "The history of the Worm People goes back centuries. I, the writer, would begin with our settlement in Dombház. Our ancestors, long, long ago, 1600 worm-years ago...",
          "buttons": [
            {
              "index": 1,
              "label": "Next page",
              "next": "4303"
            },
            {
              "index": 2,
              "label": "Close the book",
              "next": "4301"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "4303": {
          "id": "4303",
          "speaker": "The History of the Worms",
          "text": "They settled here, where we are now. Our ancestors tell us that three animals invited us here so that we could put this place in order.\n\nNext chapter: The Reign of the Three Animals",
          "buttons": [
            {
              "index": 1,
              "label": "Previous page",
              "next": "4302"
            },
            {
              "index": 2,
              "label": "Next page",
              "next": "4304"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "4304": {
          "id": "4304",
          "speaker": "The History of the Worms",
          "text": "The three animals hid their treasure in a safe, but each of them knows only one part of the code. This is what our ancestors tell us. At first, the worms lived above ground, but as time passed, they withdrew farther and farther underground. Away from the birds. By now, perhaps the birds have even forgotten about us. However...",
          "buttons": [
            {
              "index": 1,
              "label": "Previous page",
              "next": "4303"
            },
            {
              "index": 2,
              "label": "Next page",
              "next": "4305"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "4305": {
          "id": "4305",
          "speaker": "The History of the Worms",
          "text": "By now we have divided up the tasks and live in a kingdom. Every king is called the Chief Worm, so the current one is also the Chief Worm. His job is to decide who will have which job.\n\nNext chapter: The Jobs of the Worms",
          "buttons": [
            {
              "index": 1,
              "label": "Previous page",
              "next": "4304"
            },
            {
              "index": 2,
              "label": "Next page",
              "next": "4306"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "4306": {
          "id": "4306",
          "speaker": "The History of the Worms",
          "text": "The worms have many different jobs. The Miner Worm mines different kinds of crystals. The Scribe Worm's job is to look after the library and write down the stories.",
          "buttons": [
            {
              "index": 1,
              "label": "Previous page",
              "next": "4305"
            },
            {
              "index": 2,
              "label": "Next page",
              "next": "4307"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "4307": {
          "id": "4307",
          "speaker": "The History of the Worms",
          "text": "The Messenger Worm's job is to carry the Chief Worm's messages and inform him about what he sees. The Tree-Climber Worm watches the surroundings in case he finds something valuable.",
          "buttons": [
            {
              "index": 1,
              "label": "Previous page",
              "next": "4306"
            },
            {
              "index": 2,
              "label": "Next page",
              "next": "4308"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "4308": {
          "id": "4308",
          "speaker": "The History of the Worms",
          "text": "And that was the short history of the worms. I hope I taught you something.\n\nChronicler Teodor",
          "buttons": [
            {
              "index": 1,
              "label": "Previous page",
              "next": "4307"
            },
            {
              "index": 2,
              "label": "Close the book",
              "next": "HOME"
            }
          ],
          "actions": [],
          "condition": {}
        },
        "4309": {
          "id": "4309",
          "speaker": "The History of the Worms",
          "text": "The letters (and the book itself) are so tiny that you cannot read them with the naked eye.",
          "buttons": [
            {
              "index": 1,
              "label": "OK",
              "next": "HOME"
            }
          ],
          "actions": [],
          "condition": {},
          "picture": "book-too-small"
        }
      },
      "defaultPicture": "book"
    },
    "Crystal Book": {
      "displayName": "Crystal Facts",
      "startPage": "4401",
      "implemented": false,
      "pages": {},
      "defaultPicture": "book"
    }
  },
  "knowledgeFolders": {
    "merchant": "Merchant",
    "castle": "Castle",
    "troll": "Troll",
    "world": "World & Areas",
    "goblins": "Goblins",
    "messenger": "Messenger",
    "warrior": "Warrior",
    "grove": "Grove",
    "bridge": "Bridge",
    "fishing": "Fishing",
    "password": "Password"
  },
  "thingsIKnow": {
    "sweets_from_merchant": {
      "text": "Sweets can be bought from the Merchant.",
      "folder": "merchant"
    },
    "password_ending_pie": {
      "text": "The password seems to end with \"Pie\".",
      "folder": "castle"
    },
    "troll_letters_are_numbers": {
      "text": "The letters in the Troll's riddle somehow connect to numbers.",
      "folder": "troll"
    },
    "village_centre": {
      "text": "The Village Centre is one of the world's main sections.",
      "folder": "world"
    },
    "other_world_sections": {
      "text": "The other sections are the Grove, Bridge and Castle Entrance.",
      "folder": "world"
    },
    "castle_guarded_by_troll": {
      "text": "The way to the Castle Entrance is guarded by a Troll.",
      "folder": "troll"
    },
    "troll_blocks_castle": {
      "text": "The Troll must be defeated before you can reach the Castle Entrance.",
      "folder": "troll"
    },
    "mark_of_goblins": {
      "text": "Goblins will be friendlier if you show them the Mark of Goblins.",
      "folder": "goblins"
    },
    "messenger_personality": {
      "text": "The Messenger has a sweet tooth and hates running.",
      "folder": "messenger"
    },
    "warrior_weakness": {
      "text": "The Warrior can only be defeated with the Sword of Koji.",
      "folder": "warrior"
    },
    "grove_magic": {
      "text": "Something magical may be hidden in the Grove. The trees are worth checking.",
      "folder": "grove"
    },
    "fountain_shiny_object": {
      "text": "The Hunter saw something shiny between the fountain stones.",
      "folder": "grove"
    },
    "creature_in_bushes": {
      "text": "A strange creature may be hiding in one of the bushy places.",
      "folder": "grove"
    },
    "bridge_carvings": {
      "text": "There are strange carvings in the stone at the Bridge.",
      "folder": "bridge"
    },
    "guard_knows_world": {
      "text": "The city Guard knows a lot about this little empire.",
      "folder": "world"
    },
    "goblin_gold_coin_trade": {
      "text": "The Goblin would trade the Gold Coin for something from a rare animal, like a bird.",
      "folder": "goblins"
    },
    "goblin_ruby_sword_trade": {
      "text": "The Goblin would trade the Ruby Sword for another gem.",
      "folder": "goblins"
    },
    "goblin_powder_trade": {
      "text": "The Goblin would trade the Strange Powder for a shiny jewel.",
      "folder": "goblins"
    },
    "troll_riddle": {
      "text": "The Troll's riddle is: \"O, T, T, F, F, S... What are the next two letters?\"",
      "folder": "troll"
    },
    "bridge_direction": {
      "text": "From the Fisherman, the Bridge is a few meters away and to the right.",
      "folder": "bridge"
    },
    "great_salmon_time": {
      "text": "Great Salmon usually bite after about 20–25 seconds.",
      "folder": "fishing"
    },
    "troll_o_means_one": {
      "text": "In the Troll's riddle, \"O\" means \"One\".",
      "folder": "troll"
    },
    "blobfish_time": {
      "text": "Blobfish usually bite after about 12–15 seconds.",
      "folder": "fishing"
    },
    "decoder_powder": {
      "text": "Strange words written on paper may be decoded using a gray decoder powder.",
      "folder": "castle"
    },
    "password_first_part": {
      "text": "The first part of the castle password is \"Apple\".",
      "folder": "castle"
    },
    "castle_requires_password": {
      "text": "A password is required to enter the Castle.",
      "folder": "castle"
    },
    "encoded_scroll": {
      "text": "The Old Scroll contains the strange text: \"Rcuuygtf:Crrmgrkg\".",
      "folder": "castle"
    },
    "castle_password": {
      "text": "The Castle password is \"ApplePie\".",
      "folder": "castle"
    },
    "Password1": {
      "text": "Password part 1 is \"7\".",
      "folder": "password"
    },
    "Password2": {
      "text": "Password part 2 is \"891\".",
      "folder": "password"
    },
    "Password3": {
      "text": "Password part 3 is \"011\".",
      "folder": "password"
    }
  },
  "compilerNotes": [
    "PASSWORD_INPUT from the source spreadsheet is normalized to DROPDOWN_CHOICE.",
    "Item dialogues use the same page/button/action/condition shape as NPC encounters.",
    "Item dialogue buttons use next='HOME' when the design says the player returns Home.",
    "Blobfish replaces Pufferfish everywhere per the current item canon.",
    "Message Paper is normalized to Bundle of Letters per the current item canon.",
    "Staff of Goblin is normalized to Staff of Goblins per the current item canon.",
    "Magic Branch on Warrior page 1002 links to the already-existing failed rainbow-sparkle page 1010.",
    "UNLOCK_AREA is represented for Bridge Key and requires an app action handler.",
    "Horn of Trees intentionally links to NPC page 0410.",
    "Objective fixes: Buy Sweets and Get Great Salmon now complete at their actual completion points.",
    "Added side objectives for the Merchant's Blobfish request and returning the Golden Medal to the Guard.",
    "Lost Messages now completes only after Bundle of Letters is actually handed to the Messenger.",
    "Guard page 0307 now provides a route to the Golden Medal hand-in pages 0308-0310.",
    "Removed duplicate Gold Coin reward from Goblin page 0604; the reward remains on page 0608.",
    "Bridge Key now unlocks internal area id CASTLE_SIDE to match encounters 09 and 10.",
    "Warrior page 1002 now uses DROPDOWN_INVENTORY so unavailable items cannot be selected.",
    "Generic counter actions and page-level button conditions now enforce Sweets eating, Silver Ring one-time Wear, and one-time Fishing Rod catches.",
    "Items use displayName for player-facing names while item object keys remain stable internal IDs.",
    "DROPDOWN_INVENTORY options separate internal value from player-facing label; unmatched inventory items use otherNext."
  ],
  "compilerWarnings": [
    "The app must read gameData.items when an inventory item is tapped.",
    "The app must understand the HOME next target for item dialogue buttons.",
    "Item dialogue navigation must allow Horn of Trees to open NPC page 0410.",
    "The app must support generic counter actions and counter(...) page-level conditions."
  ],
  "questDisplayNames": {
    "Bird1": "Find straw for the Bird",
    "Bird2": "Find a mosquito for the Bird",
    "Bird3": "Find a nesting-place sketch for the Bird",
    "Gém1": "Bring the Heron a Golden Apple"
  }
};
